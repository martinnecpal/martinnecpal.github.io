# Image sources

## Included in the package

| File | Used on slide (id) | Origin |
|------|--------------------|--------|
| `figures/example1_feasible_region.svg/.png` | 03_gams_example1-02, -03 | made for this lecture – `code/figures/make_figures.py` |
| `figures/example3_mixer.svg/.png` | 07_gamspy_example3-02 | made for this lecture – `make_figures.py` |
| `figures/example3_graphical.svg/.png` | 07_gamspy_example3-03 | made for this lecture – `make_figures.py` |
| `figures/webapp_architecture.svg/.png` | 08_gamspy_webapp-02 | made for this lecture – `make_figures.py` |
| `figures/example3_whatif.png` | 07_gamspy_example3-10, 08_gamspy_webapp-05 | output of `code/webapp/plot_mixing.py` |
| `screenshots/webapp_screenshot.png` | 08_gamspy_webapp-11 | screenshot of `code/webapp/app.py` (water limit 22 %) |

All included images are original work for this lecture and can be regenerated:

```powershell
cd code/figures;  python make_figures.py                 # → writes into the current folder
cd code/webapp;   python plot_mixing.py                  # → mixing_whatif.png
```

## Referenced but NOT included

These are © GAMS Development Corp. (official documentation). Use them only as the
documentation allows, or replace them with your own screenshots of GAMS Studio.

| URL | Slide (id) |
|-----|------------|
| https://www.gams.com/latest/docs/studio_download.png | 02_gams_installation_studio-01 |
| https://www.gams.com/latest/docs/studio_run3.png | 02_gams_installation_studio-02 |
| https://www.gams.com/latest/docs/studio_open4.png | 02_gams_installation_studio-03 |
| https://www.gams.com/latest/docs/studio_run4.png | 02_gams_installation_studio-04 |
| https://www.gams.com/latest/docs/studio_fixerror_2.png | 02_gams_installation_studio-05 |
| https://www.gams.com/latest/docs/studio_gdx_2.png | 02_gams_installation_studio-06 |
| https://www.martinnecpal.aiplaces.org/assets/images/profile.png | 00_title_about_me-02 (own photo) |

Logos (STU, MTF, host university, Erasmus+/CEEPUS, GAMS, GAMSPy) must be taken from the
official brand pages of each organisation.

Screenshots still to be taken: see `../TODO.md`.
