---
title: "Installing GAMSPy on Windows"
section: "3 · From GAMS to GAMSPy"
slide_separator: "---"
source: "https://gamspy.readthedocs.io/en/latest/user/installation.html"
---

<!--
CONVERSION NOTES
- Each slide is separated by a line containing only `---`.
- `slide:` hint comments hold layout hints.
- `Note:` blocks are speaker notes.
- Commands were checked with GAMSPy 1.29.0 / GAMS 54.6.0 (October 2026).
-->

<!-- slide: layout=section-title -->
# 3 · From GAMS to GAMSPy
## Installing GAMSPy on Windows

---

<!-- slide: layout=two-column -->
# What is GAMSPy?

- A **Python package** for algebraic modeling – sets, parameters, variables, equations as Python objects
- Uses the **GAMS engine and solvers** in the background
- **No separate GAMS installation needed** – `pip install gamspy` brings its own GAMS core
- Works with the whole Python world: **pandas, NumPy, Matplotlib, Jupyter, web apps**
- Free **demo license** included; **free for academics** ([GAMS Academic Program](https://www.gams.com/academics/))

⚠ GAMS and GAMSPy licenses are **different** – a GAMS license cannot be used for GAMSPy.

---

<!-- slide: layout=steps -->
# Step 1 – Install Python

- GAMSPy needs **Python 3.11 or newer**
- Download from [python.org/downloads](https://www.python.org/downloads/)
- In the installer tick ✅ **"Add python.exe to PATH"**
- Check in **PowerShell**:

```powershell
python --version
```

Note:
If students already have Anaconda, they can use an Anaconda Prompt instead;
the rest of the steps are the same.

---

<!-- slide: layout=code -->
# Step 2 – Create a virtual environment

Open **PowerShell** in your working folder (e.g. `C:\GAMS_lecture`):

```powershell
python -m venv .gamspy_venv
.gamspy_venv\Scripts\Activate.ps1
```

The prompt now starts with `(.gamspy_venv)` ✅

⚠ If PowerShell blocks the script ("running scripts is disabled"):

```powershell
Set-ExecutionPolicy -Scope CurrentUser RemoteSigned
```

Note:
A virtual environment keeps the GAMSPy packages separate from other Python projects.
Using Git Bash instead of PowerShell: `source .gamspy_venv/Scripts/activate`.
Command Prompt (cmd): `.gamspy_venv\Scripts\activate.bat`.

---

<!-- slide: layout=code -->
# Step 3 – Install GAMSPy

```powershell
pip install gamspy
```

Check the installation:

```powershell
gamspy --version
```

```text
GAMSPy version: 1.29.0
GAMS version: 54.6.0
gamspy_base version: 54.6.0
```

Update later with `pip install gamspy --upgrade`

---

<!-- slide: layout=two-column -->
# Step 4 – Solvers

Show the installed solvers:

```powershell
gamspy list solvers
```

Included by default: **CPLEX** (LP, MIP), **CONOPT4** (NLP), **SBB** (MINLP), **PATH** (MCP)

Install more on demand:

```powershell
gamspy list solvers --all
gamspy install solver highs ipopt
```

Choose the solver in Python: `model.solve(solver="highs")`

---

<!-- slide: layout=code -->
# Step 5 – License (optional)

The **demo license** works out of the box for small models – enough for this lecture.

With an academic or full license (36-character access code):

```powershell
gamspy install license <access_code>
gamspy show license
```

Remove it again (back to demo): `gamspy uninstall license`

Demo limits: [GAMS documentation – demo license](https://www.gams.com/latest/docs/UG_License.html#UG_License_Additional_Solver_Limits)

---

<!-- slide: layout=code -->
# Step 6 – Test it

Save as `test_gamspy.py` and run `python test_gamspy.py`:

```python
import gamspy as gp

m = gp.Container()
x = gp.Variable(m, "x")
e = gp.Equation(m, "e")
e[...] = x >= 1

model = gp.Model(m, "test", equations=[e],
                 problem="LP", sense="min", objective=x)
model.solve()

print(model.status, model.objective_value)
```

```text
ModelStatus.OptimalGlobal 1.0
```

✅ GAMSPy is ready – next: Example 1 in Python

Note:
Recommended editors: VS Code with the Python extension, or Jupyter Notebook
(`pip install notebook`, then `jupyter notebook`). Select the `.gamspy_venv`
interpreter in VS Code (Ctrl+Shift+P → "Python: Select Interpreter").

---

<!-- slide: layout=table -->
# Quick reference

| Task | Command |
|------|---------|
| Create environment | `python -m venv .gamspy_venv` |
| Activate (PowerShell) | `.gamspy_venv\Scripts\Activate.ps1` |
| Install GAMSPy | `pip install gamspy` |
| Version | `gamspy --version` |
| List solvers | `gamspy list solvers` |
| Add a solver | `gamspy install solver <name>` |
| Install license | `gamspy install license <access_code>` |
| Show license | `gamspy show license` |

Docs: [gamspy.readthedocs.io – Installation and Licensing](https://gamspy.readthedocs.io/en/latest/user/installation.html)
