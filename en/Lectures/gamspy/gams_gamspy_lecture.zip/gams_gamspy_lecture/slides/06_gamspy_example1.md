---
title: "Example 1 in GAMSPy"
section: "4 · From GAMS to GAMSPy – Example 1"
slide_separator: "---"
source: "https://gamspy.readthedocs.io/en/latest/user/gamspy_for_gams_users.html"
---

<!--
CONVERSION NOTES
- Each slide is separated by a line containing only `---`.
- `slide:` hint comments hold layout hints.
- `Note:` blocks are speaker notes.
- Companion files: example01_gams_style.py (1:1 translation), example01.py (compact version).
- All outputs on these slides were produced with GAMSPy 1.29.0 / GAMS 54.6.0.
-->

<!-- slide: layout=section-title -->
# 4 · Example 1 in GAMSPy
## Same model – now in Python

---

<!-- slide: layout=table -->
# GAMS → GAMSPy: the dictionary

| GAMS | GAMSPy |
|------|--------|
| *(the whole .gms file)* | `m = gp.Container()` |
| `Set i / i1, i2 /;` | `i = gp.Set(m, "i", records=["i1", "i2"])` |
| `Parameter p(i) / … /;` | `p = gp.Parameter(m, "p", domain=i, records=…)` |
| `Positive Variable x;` | `x = gp.Variable(m, "x", type="positive")` |
| `Free Variable Z;` | `Z = gp.Variable(m, "Z", type="free")` |
| `Equation e;` | `e = gp.Equation(m, "e")` |
| `e.. lhs =e= rhs;` | `e[...] = lhs == rhs` |
| `=l=` / `=g=` | `<=` / `>=` |
| `sum(i, a(i))` | `gp.Sum(i, a[i])` |
| `Model mod /all/;` | `mod = gp.Model(m, "mod", equations=m.getEquations(), …)` |
| `Solve mod using LP maximizing Z;` | `problem="LP", sense="max", objective=Z` + `mod.solve()` |
| `Display x.l;` | `print(x.toValue())` or `print(x.records)` |

Note:
Key idea: every GAMS symbol becomes a Python object that lives in a Container.
`[...]` means "for all elements of the domain" – for scalar equations it simply defines the equation.

---

<!-- slide: layout=code-compare -->
# Side by side

<!-- left column -->
```gams
Positive Variables x1, x2;
Free Variable      Z;

Equations obj, eq1, eq2;

obj..  Z =e= 3*x1 + 2*x2;
eq1..  x1 + 3*x2 =l= 4;
eq2..  x1 +   x2 =l= 2;

Model Example01 /all/;
Solve Example01 maximizing Z using LP;

Display x1.l, x2.l, Z.l;
```

<!-- right column -->
```python
import gamspy as gp
m = gp.Container()

x1 = gp.Variable(m, "x1", type="positive")
x2 = gp.Variable(m, "x2", type="positive")
Z  = gp.Variable(m, "Z",  type="free")

obj = gp.Equation(m, "obj")
eq1 = gp.Equation(m, "eq1")
eq2 = gp.Equation(m, "eq2")

obj[...] = Z == 3*x1 + 2*x2
eq1[...] = x1 + 3*x2 <= 4
eq2[...] = x1 + x2 <= 2

example01 = gp.Model(m, "example01",
    equations=m.getEquations(),
    problem="LP", sense="max", objective=Z)
example01.solve()

print(x1.toValue(), x2.toValue(), Z.toValue())
```

---

<!-- slide: layout=steps -->
# How to convert – step by step

1. **Import and create a Container** – `import gamspy as gp`, `m = gp.Container()`
2. **Variables** – each declaration becomes `gp.Variable(...)` with `type=`
3. **Equations** – declare with `gp.Equation(...)`, define with `eq[...] = …`
4. **Relations** – `=e=` → `==`, `=l=` → `<=`, `=g=` → `>=`; `*` stays `*`, no `;`
5. **Model** – list of equations + `problem`, `sense`, `objective`
6. **Solve** – `model.solve()` (default LP solver: CPLEX)
7. **Results** – `.toValue()` for scalars, `.records` (pandas DataFrame) for indexed symbols

Note:
Common pitfall: writing `eq1 = x1 + 3*x2 <= 4` without `[...]` overwrites the Python
variable instead of defining the equation.

---

<!-- slide: layout=steps -->
# Run it in VS Code

1. Open the folder `C:\GAMS_lecture` – environment `.gamspy_venv` selected
2. New file `example01_gams_style.py` – paste the code, **Ctrl + S**
3. Click ▶ **Run Python File** (or right-click → *Run Python File in Terminal*)
4. Read the result in the **Terminal** panel

To see the full solver log as in GAMS Studio:

```python
import sys
example01.solve(output=sys.stdout)
```

---

<!-- slide: layout=two-column, left=code(summary), right=code(values) -->
# Results

`solve()` returns a summary table (pandas DataFrame):

```text
      Solver Status   Model Status  Objective  ...  Model Type  Solver  Solver Time
0  NormalCompletion  OptimalGlobal        6.0  ...          LP   CPLEX       0.014
```

Values:

```text
x1 = 2.0   x2 = 0.0   Z = 6.0
```

Full record of a variable – `print(x1.records)`:

```text
   level  marginal  lower  upper  scale
0    2.0       0.0    0.0    inf    1.0
```

✅ Same result as graphical solution and GAMS: **x₁ = 2, x₂ = 0, Z = 6**

<!-- optional figure: assets/figures/example1_feasible_region.svg -->

---

<!-- slide: layout=code -->
# The Python way – shorter

The objective can be written **directly as an expression** – no `Z` variable, no `obj` equation:

```python
example01 = gp.Model(m, "example01",
    equations=[eq1, eq2],
    problem="LP", sense="max",
    objective=3 * x1 + 2 * x2)
example01.solve()

print("Model status :", example01.status)
print("Objective Z  :", example01.objective_value)
print("Marginals    :", eq1.records["marginal"][0],
                         eq2.records["marginal"][0])
```

```text
Model status : ModelStatus.OptimalGlobal
Objective Z  : 6.0
Marginals    : 0.0 3.0
```

eq2 is **binding** (shadow price 3), eq1 has slack (0).

---

<!-- slide: layout=code -->
# Bonus: back to GAMS and LaTeX

A GAMSPy model can be exported as a **GAMS program**:

```python
example01.toGams("exported")      # → exported/example01.gms
example01.toLatex("latex")        # → latex/example01.tex
```

Generated `example01.gms`:

```gams
positive Variable x1;
positive Variable x2;
free Variable Z;
...
obj .. Z =e= 3 * x1 + 2 * x2;
eq1 .. x1 + 3 * x2 =l= 4;
eq2 .. x1 + x2 =l= 2;
solve example01 using LP MAX Z;
```

➡ Next: results in Python → **plots with Matplotlib**

Note:
Useful for students who want to open the model in GAMS Studio, or for papers (LaTeX export).
