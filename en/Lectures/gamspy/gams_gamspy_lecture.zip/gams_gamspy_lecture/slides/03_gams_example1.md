---
title: "Example 1 – A simple LP in GAMS"
section: "2 · Example in GAMS"
slide_separator: "---"
source: "Example adapted from Prof. Elvis Ahmetović, University of Tuzla – Erasmus+ lecture at STU, November 2025"
---

<!--
CONVERSION NOTES
- Each slide is separated by a line containing only `---`.
- `slide:` hint comments hold layout hints.
- `Note:` blocks are speaker notes.
- Companion file: Example01.gms (ready to open in GAMS Studio).
-->

<!-- slide: layout=section-title -->
# 2 · Example in GAMS
## Example 1 – a simple linear program

<small>Example adapted from Prof. Elvis Ahmetović, University of Tuzla</small>

---

<!-- slide: layout=two-column, right=image(assets/figures/example1_feasible_region.svg) -->
# The problem

**Maximize**  Z = 3x₁ + 2x₂

**subject to**
- x₁ + 3x₂ ≤ 4
- x₁ + x₂ ≤ 2
- x₁, x₂ ≥ 0

Two variables → we can solve it **graphically** and then check the result **in GAMS**.


---

<!-- slide: layout=two-column, left=image(assets/figures/example1_feasible_region.svg), right=table -->
# Graphical solution

Feasible region = polygon **A B C D**. The optimum of an LP lies in a **corner point**.

| Corner | (x₁, x₂) | Z = 3x₁ + 2x₂ |
|--------|----------|---------------|
| A | (0, 0) | 0 |
| **B** | **(2, 0)** | **6** ✅ |
| C | (1, 1) | 5 |
| D | (0, 4/3) | 8/3 |

Point C: intersection of x₁ + 3x₂ = 4 and x₁ + x₂ = 2 → x₂ = 1, x₁ = 1

**Optimum: x₁ = 2, x₂ = 0, Z = 6**

---

<!-- slide: layout=code-left, annotations-right -->
# The same model in GAMS

```gams
$Title Simple LP optimisation problem

Positive Variables x1, x2;
Free Variable      Z;

Equations obj, eq1, eq2;

obj..  Z =e= 3*x1 + 2*x2;
eq1..  x1 + 3*x2 =l= 4;
eq2..  x1 +   x2 =l= 2;

Model Example01 /all/;
Solve Example01 maximizing Z using LP;

Display x1.l, x2.l, Z.l;
```

---

<!-- slide: layout=table -->
# Reading the code line by line

| Statement | Meaning |
|-----------|---------|
| `Positive Variables x1, x2;` | Decision variables with bound x ≥ 0 |
| `Free Variable Z;` | Objective variable – must be **free** (no sign restriction) |
| `Equations obj, eq1, eq2;` | **Declare** the equation names |
| `obj.. Z =e= …;` | **Define** the equation; `..` separates name and body |
| `=e=` `=l=` `=g=` | equal · less or equal (≤) · greater or equal (≥) |
| `Model Example01 /all/;` | Model consists of all declared equations |
| `Solve … maximizing Z using LP;` | Direction, objective variable, model type |
| `Display x1.l, …;` | Print **level** (`.l`) = optimal value |

Every statement ends with **`;`** – the most common beginner error!

Note:
Mention other attributes: .lo and .up for bounds, .m for marginals (shadow prices).

---

<!-- slide: layout=steps, right=image(TODO: assets/screenshots/gams_studio_example01.png) -->
# Running it in GAMS Studio

1. *File → New Project…* → folder e.g. `GAMS_lecture`
2. *File → New…* → `Example01.gms`, type or paste the code
3. Save (**Ctrl + S**) – check the green ▶ main-file marker
4. Press **F9** (or the green Run button)
5. The Process Log shows the run; `Example01.lst` opens automatically

<!-- image: own screenshot of GAMS Studio with Example01.gms and Example01.lst tabs -->

Note:
Do this live. Deliberately delete one semicolon first to show what a compilation
error looks like (red line in the Process Log, `$` marker in the .lst file), then fix it.

---

<!-- slide: layout=two-column, left=code(solve_summary), right=code(display) -->
# Results in the listing file

```text
               S O L V E      S U M M A R Y

     MODEL   Example01           OBJECTIVE  Z
     TYPE    LP                  DIRECTION  MAXIMIZE
     SOLVER  CPLEX               FROM LINE  18

**** SOLVER STATUS     1 Normal Completion
**** MODEL STATUS      1 Optimal
**** OBJECTIVE VALUE            6.0000
```

```text
----     20 VARIABLE x1.L  =  2.000
            VARIABLE x2.L  =  0.000
            VARIABLE Z.L   =  6.000
```

✅ Same as the graphical solution: **x₁ = 2, x₂ = 0, Z = 6**
Default LP solver: **CPLEX**

Note:
Output copied from a real run of code/gams/Example01.gms with GAMS 54.6 (see Example01.lst).
"FROM LINE" and the display line number refer to that exact file.

---

<!-- slide: layout=bullets -->
# Try it yourself

- Change the objective to **Z = 2x₁ + 3x₂** – which corner wins now?
- Look at the **marginals** `eq1.m`, `eq2.m` – which constraint is binding?
- Switch the solver: add `option LP = HiGHS;` before `Solve`
- Change `maximizing` to `minimizing` – what happens and why?

➡ Next: the same model in **Python with GAMSPy**

Note:
Answers: Z = 2x1 + 3x2 → point C (1,1), Z = 5 (D gives 4).
eq2 is binding at B (marginal 3), eq1 is not (marginal 0).
Minimizing gives the trivial solution A(0,0), Z = 0.
