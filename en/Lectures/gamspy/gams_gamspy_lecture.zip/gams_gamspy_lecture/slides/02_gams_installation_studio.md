---
title: "Installing GAMS and working with GAMS Studio"
section: "1 · Introduction (continued)"
slide_separator: "---"
---

<!--
CONVERSION NOTES
- Each slide is separated by a line containing only `---`.
- `slide:` hint comments hold layout hints; `image(...)` gives the picture to place.
- Images marked https://www.gams.com/... are official screenshots from the GAMS documentation;
  they are NOT included in the package (see assets/IMAGE_SOURCES.md) – download them or replace with own screenshots.
  Replace them with your own screenshots if you prefer (e.g. Slovak/English UI, your workspace).
- `Note:` blocks are speaker notes.
-->

<!-- slide: layout=two-column, right=image(https://www.gams.com/latest/docs/studio_download.png) -->
# Installing GAMS

**1. Download** – [www.gams.com/download](https://www.gams.com/download/)
- Windows (x86_64), Linux (x86_64 / ARM64), macOS (Intel / Apple M)
- Check the [release notes](https://www.gams.com/latest/docs/RN_MAIN.html) and [installation notes](https://www.gams.com/latest/docs/UG_MAIN.html#UG_INSTALL)

**2. Install** – run the installer
- **GAMS Studio is installed automatically** together with GAMS
- Windows may show a SmartScreen warning → *More info → Run anyway*

**3. License**
- A **free demo license** (size-limited) comes with every download
- Free / academic licenses: [www.gams.com/free-licenses](https://www.gams.com/free-licenses/)
- In Studio: *Help → GAMS Licensing* to paste or check the license

Note:
Do the installation live or show it as a short screen recording; on Windows it takes a few minutes.
Students should install before the hands-on part.

---

<!-- slide: layout=image-full, image=https://www.gams.com/latest/docs/studio_run3.png -->
# GAMS Studio at a glance

![GAMS Studio main window](https://www.gams.com/latest/docs/studio_run3.png)

| Area | Purpose |
|------|---------|
| **Project Explorer** (left) | Files of the project; main file marked with a green ▶ |
| **Code Editor** (centre) | Model `.gms` with syntax highlighting and code completion |
| **Listing file** `.lst` | Results: solve summary, equations, variables |
| **Process Log** | Run messages, errors, clickable links |
| **Toolbar** | New · Open · Save · Model Library · **Run (F9)** |

---

<!-- slide: layout=steps -->
# Your first run in 5 steps

1. **Create a project** – *File → New Project…*, choose a working folder
2. **Open a model** – *GAMS → Model Library Explorer* (**F6**) → `trnsport`
   or *File → New…* → `my_model.gms`
3. **Check the main file** – green ▶ in the Project Explorer
   (*right-click → Set as Main File*)
4. **Run** – green ▶ button or **F9**
5. **Read the results** – Process Log + `.lst` file opens automatically

![Model Library Explorer](https://www.gams.com/latest/docs/studio_open4.png)

Note:
Important for students: Studio runs the *main file* of the project,
not necessarily the file currently open in the editor.

---

<!-- slide: layout=two-column, left=image(https://www.gams.com/latest/docs/studio_run4.png), right=text -->
# Reading the output

**Process Log – colour of lines**

| Colour | Double-click opens |
|--------|--------------------|
| 🔵 Blue | The `.lst` file at that place |
| 🔴 Red | **Error** – jumps to the line in the source |
| 🟢 Green | Created files (GDX, REF, PUT) |

**Listing file (`.lst`)** – the navigation tree on the left jumps to:
Compilation · Equation listing · Model statistics · **Solution report** · Display

Look first at:
`SOLVER STATUS 1 Normal Completion` · `MODEL STATUS 1 Optimal` · `OBJECTIVE VALUE`

---

<!-- slide: layout=two-column, right=image(https://www.gams.com/latest/docs/studio_fixerror_2.png) -->
# Finding and fixing errors

- Errors appear as **red lines** in the Process Log
- **Always start with the first error** – later ones are often consequences
- Click the red line → cursor jumps to the error in the `.gms` file
- In the `.lst` file the error position is marked with **`$`** and an error number
- Common beginner errors: missing `;`, undeclared symbol, misspelled set element, `=e=` written as `=`

---

<!-- slide: layout=two-column, right=image(https://www.gams.com/latest/docs/studio_gdx_2.png) -->
# More useful Studio tools

- **GDX Viewer** – browse sets, parameters and solution values as tables; export to Excel
- **Model Library Explorer** (F6) – 400+ ready-to-run example models
- **Solver option editor** – create `conopt.opt`, `cplex.opt`… with a form
- **Integrated help** (F1) – documentation for the keyword under the cursor
- **Debugger** – breakpoints, inspect data during execution
- **Run on NEOS / GAMS Engine** – solve remotely

---

<!-- slide: layout=table -->
# Handy shortcuts

| Action | Windows / Linux | macOS |
|--------|-----------------|-------|
| Run model | **F9** | **F9** |
| Compile only | Shift + F9 | Shift + F9 |
| Model Library | F6 | F6 |
| Help on keyword | F1 | F1 |
| Code completion | Ctrl + Space | Ctrl + Space |
| Comment / uncomment | Ctrl + * | Cmd + * |
| Matching bracket | Ctrl + B | Cmd + B |
| Navigator (find file / line) | Ctrl + K | Ctrl + K |

➡ Next: our first example written in GAMS

---

<!-- slide: layout=references -->
# Links

- Download: https://www.gams.com/download/
- Installation & licensing: https://www.gams.com/latest/docs/UG_MAIN.html#UG_INSTALL
- Free licenses: https://www.gams.com/free-licenses/
- GAMS Studio manual: https://www.gams.com/latest/docs/T_STUDIO.html
- GAMS Studio tutorial (B. McCarl): https://www.gams.com/latest/docs/UG_studio_tutorial.html
