---
title: "Summary, acknowledgements and Q&A"
section: "7 · Closing"
slide_separator: "---"
---

<!-- slide: layout=summary -->
# What we learned today

| | GAMS | GAMSPy |
|---|------|--------|
| Language | own algebraic language (`.gms`) | Python package |
| Environment | GAMS Studio | VS Code / Jupyter |
| Results | listing file `.lst`, GDX | pandas DataFrames, `.toValue()` |
| Data | tables in the model, GDX | pandas, Excel, databases |
| Visualization / apps | GAMS MIRO | Matplotlib, Flask, any Python tool |
| Solvers | same: CPLEX, CONOPT, BARON, HiGHS, … | same |

**Same algebraic model – two ways to write it.** Choose GAMS for pure modelling,
GAMSPy when the model is part of a bigger Python workflow.

---

<!-- slide: layout=bullets -->
# Where to continue

- GAMS Model Library – 400+ models, many from chemical and mechanical engineering
- GAMSPy examples – https://github.com/GAMS-dev/gamspy-examples
- GAMSPy for GAMS users – https://gamspy.readthedocs.io/en/latest/user/gamspy_for_gams_users.html
- All code from today: [link to the course repository / download – TODO]

**Homework idea:** extend Example 3 with a third feed and a minimum MEA content,
then show the result in the web app.

---

<!-- slide: layout=acknowledgements, logos=[TODO: ERASMUS+ or CEEPUS, STU, MTF STU, HOST UNIVERSITY] -->
# Acknowledgements

- Examples 1 and 3 adapted from the lecture of **Prof. Elvis Ahmetović**
  (University of Tuzla) – *Mathematical modelling in GAMS*, Erasmus+ lecture at STU, November 2025
- Example 3 problem from M. R. Eden: *Process Synthesis, Simulation and Optimization*, 2011
- [ERASMUS+ / CEEPUS] programme and the host university **[HOST UNIVERSITY]**

---

<!-- slide: layout=closing -->
# Thank you!

**Questions?**

Martin Necpal · martin.necpal@stuba.sk · martinnecpal.aiplaces.org
