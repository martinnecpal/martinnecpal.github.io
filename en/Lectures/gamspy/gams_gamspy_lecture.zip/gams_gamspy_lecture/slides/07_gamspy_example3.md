---
title: "Example 3 – Mixing of streams in GAMSPy"
section: "5 · GAMSPy – sets, parameters and data"
slide_separator: "---"
source: "Example after Prof. Elvis Ahmetović (University of Tuzla); problem from M. R. Eden, Process Synthesis, Simulation and Optimization, 2011"
---

<!--
CONVERSION NOTES
- Each slide is separated by a line containing only `---`.
- `slide:` hint comments hold layout hints.
- `Note:` blocks are speaker notes.
- Companion files: example03_simple.py (direct translation), example03_indexed.py (sets + parameters + what-if loop).
- All outputs were produced with GAMSPy 1.29.0 / GAMS 54.6.0.
-->

<!-- slide: layout=section-title -->
# 5 · Example 3 – Mixing of streams
## Sets, parameters and data in GAMSPy

<small>Example after Prof. Elvis Ahmetović; problem from M. R. Eden (2011)</small>

---

<!-- slide: layout=two-column, right=image(assets/figures/example3_mixer.svg) -->
# The problem

Two feed streams are mixed to produce an **MEA/water mixture**.

| Feed | MEA | Water | Cost |
|------|-----|-------|------|
| Feed 1 | 80 % | 20 % | 80 cent/kg |
| Feed 2 | 68 % | 32 % | 60 cent/kg |

**Product:** max. **25 mass.% water**
**Question:** which mixing ratio gives the **minimum cost** per 1 kg of mixture?


---

<!-- slide: layout=two-column, right=image(assets/figures/example3_graphical.svg) -->
# Mathematical formulation

**Variables** (basis 1 kg mixture)
- m₁, m₂ – mass of feed 1 and feed 2 [kg]
- z – cost of 1 kg mixture [cent]

**min** z = 80 m₁ + 60 m₂

**s.t.**
- 0.20 m₁ + 0.32 m₂ ≤ 0.25 &nbsp; *(water content)*
- m₁ + m₂ = 1 &nbsp; *(mass balance)*
- m₁, m₂ ≥ 0

Expected result (graphical): m₁ = 0.583, m₂ = 0.417, z = 71.67 cent/kg

Note:
In the original GAMS lecture the model was solved with `using NLP`. All equations
are linear, so `LP` is the correct model type – a good discussion point for students.

---

<!-- slide: layout=code -->
# Step 1 – direct translation

```python
import gamspy as gp
m = gp.Container()

m1 = gp.Variable(m, "m1", type="positive", description="mass of feed 1 [kg]")
m2 = gp.Variable(m, "m2", type="positive", description="mass of feed 2 [kg]")
z  = gp.Variable(m, "z",  type="free",     description="cost [cent/kg]")

obj     = gp.Equation(m, "obj")
water   = gp.Equation(m, "water")
balance = gp.Equation(m, "balance")

obj[...]     = z == 80 * m1 + 60 * m2
water[...]   = 0.20 * m1 + 0.32 * m2 <= 0.25
balance[...] = m1 + m2 == 1

mixing = gp.Model(m, "mixing", equations=m.getEquations(),
                  problem="LP", sense="min", objective=z)
mixing.solve()
```

```text
z  = 71.667 cent/kg
m1 = 0.583 kg   m2 = 0.417 kg
```

✅ Same as Example 1 – only new: `==` for the balance and `description=` texts.

---

<!-- slide: layout=two-column -->
# Problem: numbers are inside the equations

- Costs and compositions are **hard-coded** in the equations
- A 3rd feed or a 3rd component → rewrite the whole model
- Real models have **hundreds of streams** and data from Excel / databases

**Solution: separate model and data**

| Concept | GAMS | GAMSPy |
|---------|------|--------|
| Index set | `Set f /feed1, feed2/;` | `gp.Set(m, "f", records=[...])` |
| Data | `Parameter cost(f) /.../;` | `gp.Parameter(m, "cost", domain=f, records=...)` |
| Table | `Table w(f,c)` | `gp.Parameter(..., domain=[f, c], records=DataFrame)` |
| Indexed variable | `x(f)` | `gp.Variable(m, "x", domain=f)` |
| Sum | `sum(f, cost(f)*x(f))` | `gp.Sum(f, cost[f] * x[f])` |

---

<!-- slide: layout=two-column -->
# Step 2 – general (indexed) formulation

**Sets:** f – feeds, c – components

**Parameters:** cost(f), w(f,c) mass fraction, wmax(c) limit, M product amount

**Variable:** x(f) ≥ 0 – mass of feed f in product

**min** Σ_f cost(f) · x(f)

**s.t.**
- Σ_f w(f,c) · x(f) ≤ wmax(c) · M &nbsp; for every c with a limit
- Σ_f x(f) = M

➡ The model **does not change** when you add feeds or components – only the data.

---

<!-- slide: layout=code -->
# Sets and data

```python
import pandas as pd
import gamspy as gp

m = gp.Container()

# Sets
f = gp.Set(m, "f", records=["feed1", "feed2"], description="feed streams")
c = gp.Set(m, "c", records=["MEA", "water"],  description="components")

# Data – composition as a pandas DataFrame (could come from Excel)
composition = pd.DataFrame(
    [["feed1", "MEA", 0.80], ["feed1", "water", 0.20],
     ["feed2", "MEA", 0.68], ["feed2", "water", 0.32]],
    columns=["f", "c", "value"])

w    = gp.Parameter(m, "w", domain=[f, c], records=composition)
cost = gp.Parameter(m, "cost", domain=f, records=[["feed1", 80], ["feed2", 60]])
wmax = gp.Parameter(m, "wmax", domain=c, records=[["water", 0.25]])
M    = gp.Parameter(m, "M", records=1)
```

Note:
Reading from Excel would be one line: `pd.read_excel("feeds.xlsx")` – a natural
advantage of GAMSPy over plain GAMS for students who already know pandas.

---

<!-- slide: layout=code -->
# Variables, equations, model

```python
x = gp.Variable(m, "x", type="positive", domain=f)

spec    = gp.Equation(m, "spec", domain=c)
balance = gp.Equation(m, "balance")

# one equation for every component c that has a limit
spec[c].where[wmax[c]] = gp.Sum(f, w[f, c] * x[f]) <= wmax[c] * M
balance[...]           = gp.Sum(f, x[f]) == M

mixing = gp.Model(m, "mixing", equations=m.getEquations(),
                  problem="LP", sense="min",
                  objective=gp.Sum(f, cost[f] * x[f]))
mixing.solve()
```

| GAMSPy | GAMS equivalent |
|--------|-----------------|
| `spec[c]` | `spec(c)..` – equation for each c |
| `.where[wmax[c]]` | `$wmax(c)` – only where a limit exists |
| `gp.Sum(f, …)` | `sum(f, …)` |

---

<!-- slide: layout=two-column -->
# Results

```python
print(mixing.objective_value)
print(x.records[["f", "level"]])
```

```text
Minimum cost: 71.667 cent/kg
       f     level
0  feed1  0.583333
1  feed2  0.416667
```

Check the product composition:

```python
product = gp.Parameter(m, "product", domain=c)
product[c] = gp.Sum(f, w[f, c] * x.l[f]) / M
```

```text
       c  value
0    MEA   0.75
1  water   0.25    ← constraint is active
```

---

<!-- slide: layout=code, right=image(assets/figures/example3_whatif.png) -->
# What-if: change the water limit

Python loop – change data, solve again, no model rewriting:

```python
for limit in [0.20, 0.22, 0.25, 0.28, 0.32]:
    wmax.setRecords([["water", limit]])
    mixing.solve()
    x1, x2 = x.records["level"]
    print(limit, mixing.objective_value, x1, x2)
```

| Water limit | Cost [cent/kg] | Feed 1 | Feed 2 |
|-------------|----------------|--------|--------|
| 0.20 | 80.000 | 1.000 | 0.000 |
| 0.22 | 76.667 | 0.833 | 0.167 |
| **0.25** | **71.667** | **0.583** | **0.417** |
| 0.28 | 66.667 | 0.333 | 0.667 |
| 0.32 | 60.000 | 0.000 | 1.000 |

➡ Next: turn this table into a **plot with Matplotlib**

Note:
Below 0.20 the problem is infeasible (even pure feed 1 has 20 % water);
above 0.32 the limit is no longer active and the cheapest feed 2 is used alone.

---

<!-- slide: layout=bullets -->
# Try it yourself

- Add a **third feed**: 90 % MEA, 10 % water, 95 cent/kg – only the data changes!
- Add a **minimum MEA content** of 72 % – one more record in a parameter (hint: use a `wmin(c)` and a `>=` equation)
- Produce **M = 1000 kg** instead of 1 kg
- What happens with a water limit of **0.15**? Check `mixing.status`

Note:
For 0.15 the model status is infeasible – good moment to show how to read model status in Python.
