---
title: "Working with GAMSPy in Visual Studio Code"
section: "3 · From GAMS to GAMSPy (continued)"
slide_separator: "---"
source: "https://code.visualstudio.com/docs/python/python-tutorial"
---

<!--
CONVERSION NOTES
- Each slide is separated by a line containing only `---`.
- `slide:` hint comments hold layout hints; image(...) = screenshot placeholder.
- `Note:` blocks are speaker notes.
-->

<!-- slide: layout=steps, right=image(TODO: assets/screenshots/vscode_download.png) -->
# Step 1 – Install VS Code

1. Download from [code.visualstudio.com](https://code.visualstudio.com/) → **Download for Windows**
2. Run the installer and tick:
   - ✅ **Add "Open with Code" action** to the Explorer context menu (files and folders)
   - ✅ **Add to PATH**
3. Start VS Code

VS Code is **free**, light and runs on Windows, macOS and Linux.

---

<!-- slide: layout=two-column, right=image(TODO: assets/screenshots/vscode_python_extension.png) -->
# Step 2 – Python extension

1. Open **Extensions** (**Ctrl + Shift + X**)
2. Search **Python** → install the extension by **Microsoft** (`ms-python.python`)
3. The **Python Debugger** is installed automatically with it

Optional: **Jupyter** extension (Microsoft) for notebooks (`.ipynb`)

⚠ The extension does **not** include Python itself – Python 3.11+ must be installed first (see previous section).

---

<!-- slide: layout=steps -->
# Step 3 – Open your project folder

- *File → Open Folder…* → e.g. `C:\GAMS_lecture`
- or right-click the folder in Windows Explorer → **Open with Code**
- Confirm **"Yes, I trust the authors"**

One folder = one project – your `.py` files and `.gamspy_venv` live here.

---

<!-- slide: layout=two-column, right=image(TODO: assets/screenshots/vscode_select_interpreter.png) -->
# Step 4 – Select the Python environment

Open the Command Palette **Ctrl + Shift + P**:

**A) Environment already exists** (created in the GAMSPy installation step)
→ `Python: Select Interpreter` → choose **`.gamspy_venv`**

**B) Create a new one directly in VS Code**
→ `Python: Create Environment` → **Venv** → choose your Python 3.11+

The selected environment is shown in the **status bar** (bottom right).

Note:
If students skipped the PowerShell steps, option B is the easiest path:
VS Code creates `.venv` in the folder and activates it automatically.

---

<!-- slide: layout=code -->
# Step 5 – Install GAMSPy in the environment

Open the integrated terminal: **Terminal → New Terminal** (**Ctrl + Shift + `**)

The prompt should start with the environment name, e.g. `(.gamspy_venv)` ✅

```powershell
pip install gamspy matplotlib
gamspy --version
```

We install **Matplotlib** now as well – we will need it for plotting results later.

---

<!-- slide: layout=two-column, left=code, right=image(TODO: assets/screenshots/vscode_run_button.png) -->
# Step 6 – Run your first script

Create `test_gamspy.py`, paste the test model, save (**Ctrl + S**):

- Click ▶ **Run Python File** (top right of the editor), or
- Right-click → *Run Python → Run Python File in Terminal*
- Select lines + **Shift + Enter** → run only the selection

Output appears in the **Terminal** panel:

```text
ModelStatus.OptimalGlobal 1.0
```

---

<!-- slide: layout=table -->
# VS Code shortcuts for this lecture

| Action | Shortcut |
|--------|----------|
| Command Palette | **Ctrl + Shift + P** |
| Extensions | Ctrl + Shift + X |
| New terminal | Ctrl + Shift + ` |
| Run selection in terminal | Shift + Enter |
| Debug (start) | F5 |
| Comment / uncomment line | Ctrl + / |
| Quick open file | Ctrl + P |

➡ Next: Example 1 written in **GAMSPy**
