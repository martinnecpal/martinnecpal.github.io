---
title: "Title, about me and agenda"
section: "0 · Opening"
slide_separator: "---"
---

<!--
CONVERSION NOTES
- Each slide is separated by a line containing only `---`.
- `slide:` hint comments hold layout hints.
- `Note:` blocks are speaker notes.
- [PLACEHOLDERS] must be filled in before the lecture.
-->

<!-- slide: layout=title, logos=[TODO: STU, MTF STU, HOST UNIVERSITY, ERASMUS+ or CEEPUS] -->
# From GAMS to GAMSPy
## Optimization modelling in Python – from model to interactive web page

**Martin Necpal**
Faculty of Materials Science and Technology in Trnava
Slovak University of Technology in Bratislava

[ERASMUS+ / CEEPUS] lecture · [HOST UNIVERSITY] · [DATE]

Note:
Thank the hosts for the invitation. One sentence on what the audience will take home:
write a model in GAMS, the same model in Python with GAMSPy, and turn it into a web page.

---

<!-- slide: layout=two-column, left=photo, right=text, photo=https://www.martinnecpal.aiplaces.org/assets/images/profile.png -->
# About me

**Martin Necpal**
University lecturer, Institute of Production Technology
Faculty of Materials Science and Technology in Trnava
Slovak University of Technology in Bratislava, Slovakia

- **PhD (2010):** Automated Process Planning and Integration into Current CAx Systems
- **CAD / CAM** applications and NC programming
- **Laser machining** on the 5-axis LASERTEC 80 Shape: teaching, student theses, research projects
- **Python, MATLAB, data science and AI / machine learning**: exploring new technologies and their practical use

✉ martin.necpal@stuba.sk · 🌐 martinnecpal.aiplaces.org
ORCID 0000-0003-2142-9204 · GitHub: martinnecpal

Note:
Keep to about one minute. Bridge to the lecture topic: Python and optimization are a natural
step from process planning and manufacturing, which leads into GAMS and GAMSPy.
Photo: download it from the URL above into assets/photos/profile.png (not included in the package).

---

<!-- slide: layout=agenda -->
# Agenda

1. **Introduction to GAMS** – what it is, where it is used, installation, GAMS Studio
2. **Example 1 in GAMS** – a simple LP, graphical vs. GAMS solution
3. **Getting ready for GAMSPy** – Python, GAMSPy, Visual Studio Code
4. **Example 1 in GAMSPy** – translating GAMS to Python
5. **Example 3 in GAMSPy** – mixing of streams with sets, parameters and data
6. **From model to web page** – Matplotlib and Flask, step by step
7. **Summary & Q&A**
