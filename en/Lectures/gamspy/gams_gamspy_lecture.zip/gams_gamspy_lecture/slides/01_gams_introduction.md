---
title: "Introduction to GAMS"
section: "1 · Introduction"
slide_separator: "---"
---

<!--
CONVERSION NOTES
- Each slide is separated by a line containing only `---`.
- `slide:` hint comments hold layout hints.
- `Note:` blocks are speaker notes, not shown on the slide.
-->

<!-- slide: layout=section-title -->
# 1 · Introduction to GAMS
## General Algebraic Modeling System

---

<!-- slide: layout=two-column, right=image(TODO: assets/logos/gams_logo.svg) -->
# What is GAMS?

- A **high-level algebraic modeling language** for mathematical optimization
- You write the model **as mathematics** (sets, parameters, variables, equations)
- GAMS **compiles** the model and passes it to a **solver**
- The same model can be solved with **different solvers** without rewriting it
- Handles **linear, nonlinear, discrete, stochastic and equilibrium** models at large scale

**Key idea:** separate *what* the problem is (the model) from *how* it is solved (the solver).

Note:
Emphasize the separation of model and solver. Engineers describe the physics/economics;
the solver handles the numerical algorithm.

---

<!-- slide: layout=timeline -->
# A short history

| Year | Milestone |
|------|-----------|
| 1976 | Started as a research project at the **World Bank** (Alexander Meeraus) |
| 1987 | GAMS becomes a commercial product |
| 2001 | GDX data exchange format introduced |
| 2012 | INFORMS Impact Prize for the originators of algebraic modeling languages |
| 2018 | **GAMS Studio** – the current IDE |
| 2023 | **GAMSPy** – algebraic modeling in Python with GAMS as the engine |

Today: GAMS 54.x, GAMSPy 1.29 (October 2026)

Note:
GAMS was born from the frustration of economists at the World Bank writing large models
by hand as matrix generators. The aim was one model representation readable by humans and machines.

---

<!-- slide: layout=four-cards -->
# The GAMS ecosystem

| Product | Purpose |
|---------|---------|
| **GAMS Language** | Algebraic modeling language + GAMS Studio IDE |
| **GAMSPy** | Python-native interface – the same modeling power inside Python |
| **GAMS MIRO** | Turns a model into an interactive web application for non-experts |
| **GAMS Engine** | Runs optimization jobs at scale (parallel, cloud, large memory) |

Note:
Today's lecture covers the first two in depth and touches on the idea behind MIRO
when we build our own simple web page with Python.

---

<!-- slide: layout=diagram, diagram=workflow (build as React component: 4 boxes with arrows) -->
# How GAMS works

```
 Model file (.gms)  ──►  GAMS compiler  ──►  Solver  ──►  Listing file (.lst)
   sets, data,           checks syntax,      CPLEX,       solver status,
   variables,            generates the       CONOPT,      model status,
   equations             model instance      BARON …      variable values
```

Structure of a GAMS model:
**Sets → Data (Parameters, Tables, Scalars) → Variables → Equations → Model → Solve → Display**

---

<!-- slide: layout=table -->
# Problem types and solvers

| Model type | Meaning | Typical solvers |
|-----------|---------|-----------------|
| **LP** | Linear programming | CPLEX, HiGHS, Gurobi, XPRESS |
| **MIP** | Mixed-integer linear | CPLEX, HiGHS, Gurobi, SCIP |
| **NLP** | Nonlinear programming | CONOPT, IPOPT, SNOPT, KNITRO |
| **MINLP** | Mixed-integer nonlinear | DICOPT, SBB, SHOT, BARON |
| **QCP / MIQCP** | Quadratic constraints | CPLEX, Gurobi, MOSEK |
| **MCP / MPEC** | Equilibrium / complementarity | PATH, NLPEC |
| **Global** | Proven global optimum | BARON, SCIP |

Switching solver = one line: `option NLP = BARON;`

Note:
Local vs. global NLP solvers: CONOPT/IPOPT find a local optimum, BARON proves the global one.

---

<!-- slide: layout=icons-grid -->
# Where is GAMS used?

- **Energy systems** – power planning, unit commitment, energy management, carbon capture & storage
- **Economics & policy** – CGE models, international trade (e.g. OECD METRO)
- **Agriculture, water and forestry** – resource allocation, water networks
- **Finance** – portfolio and risk optimization
- **Logistics & operations** – transport, scheduling, inventory, vehicle routing
- **Engineering** – chemical processes, mechanical design, manufacturing

Case studies on gams.com: OECD, TotalEnergies (CCS), Alpro (factory energy management), Rhodium Group

---

<!-- slide: layout=two-column, left=text, right=image(optional: TODO process flowsheet picture) -->
# GAMS in chemical engineering

Classic field of application (Grossmann, CMU, and many others)

- **Process synthesis** – flowsheet structure (MINLP)
- **Heat exchanger networks** – heat integration
- **Distillation** – column sequencing, feed tray location
- **Reactor networks & kinetics** – parameter estimation
- **Pooling and blending** – refineries, petrochemicals
- **Batch plants** – design and scheduling

**Examples in the GAMS Model Library**
`process` alkylation · `procsel` flowsheet selection · `synheat` HEN synthesis ·
`feedtray` feed plate location · `hda` toluene hydrodealkylation ·
`batchdes` batch plant design · `haverly`, `pool` pooling · `methanol`, `gasoil` kinetics

Note:
All library models can be opened directly in GAMS Studio: GAMS → Model Library Explorer.
Link to the stream-mixing example from the previous lecture as the simplest blending case.

---

<!-- slide: layout=two-column, left=text, right=image(optional: TODO gear / machine part picture) -->
# GAMS in mechanical & manufacturing engineering

- **Machine element design** – gears, springs, bearings
- **Structural optimization** – trusses, structures, shape optimization
- **Optimal control & dynamics** – robot arm, trajectories
- **Manufacturing** – trim loss / cutting stock, production planning, flow shop scheduling
- **Energy in production** – machine scheduling for energy cost

**Examples in the GAMS Model Library**
`gear` gear train design · `spring` coil compression spring · `bearing` hydrostatic thrust bearing ·
`jbearing` journal bearing · `trussm` truss topology · `camshape` cam shape ·
`robot` robot arm · `trimloss` / `cutstock` cutting · `flowshop`, `prodplan`, `rcpsp` scheduling

Note:
Connect to my own field: process planning and machining are full of optimization problems,
e.g. cutting parameters (NLP), operation sequencing (MIP), nesting / cutting stock (MIP).

---

<!-- slide: layout=bullets -->
# Why should engineers use GAMS?

- Model reads like the **mathematical formulation** on paper
- **Same model, many solvers** – compare local vs. global results
- Scales from **classroom examples to industrial models**
- **450+ ready models** in the GAMS Model Library to learn from
- Free **demo license** included with every download; academic licenses available
- With **GAMSPy** the model lives inside Python – data, plots, web apps

➡ Next: one example, first in **GAMS**, then in **GAMSPy**

---

<!-- slide: layout=references -->
# Resources

- GAMS homepage: https://www.gams.com
- GAMS documentation: https://www.gams.com/latest/docs/
- GAMS Model Library: https://www.gams.com/latest/gamslib_ml/libhtml/
- GAMSPy documentation: https://gamspy.readthedocs.io
- GAMSPy examples: https://github.com/GAMS-dev/gamspy-examples
- Brooke, Kendrick, Meeraus, Raman: *GAMS – A User's Guide*
