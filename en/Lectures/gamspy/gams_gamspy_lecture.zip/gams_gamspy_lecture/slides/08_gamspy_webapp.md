---
title: "From GAMSPy model to an interactive web page"
section: "6 · GAMSPy + Matplotlib + Flask"
slide_separator: "---"
---

<!--
CONVERSION NOTES
- Each slide is separated by a line containing only `---`.
- `slide:` hint comments hold layout hints; image(...) = file from the webapp folder.
- `Note:` blocks are speaker notes.
- Companion folder: webapp/ (all files below). Tested with GAMSPy 1.29.0, Matplotlib 3.11, Flask 3.1.
- Every step ends with a ✅ TEST box – run it before moving on.
-->

<!-- slide: layout=section-title -->
# 6 · From model to web page
## GAMSPy + Matplotlib + Flask – in 7 testable steps

---

<!-- slide: layout=diagram, image=assets/figures/webapp_architecture.svg -->
# What we are going to build

```
 Browser (sliders)  ──►  Flask (app.py)  ──►  GAMSPy model      ──►  CPLEX
        ▲                     │              (mixing_model.py)
        │                     ▼
        └──── JSON + PNG ◄──  Matplotlib chart (plot_mixing.py)
```

| File | Step | Role |
|------|------|------|
| `mixing_model.py` | 2 | Example 3 as a Python function |
| `plot_mixing.py` | 3 | What-if chart with Matplotlib |
| `app_step4.py` … `app_step6.py` | 4–6 | Flask, growing step by step |
| `app.py` + `templates/index.html` | 7 | Final interactive page |

---

<!-- slide: layout=code -->
# Step 1 – Install Matplotlib and Flask

In the VS Code terminal with the `.gamspy_venv` environment active:

```powershell
pip install matplotlib flask
```

✅ **TEST**

```powershell
python -c "import gamspy, matplotlib, flask; print('all OK')"
```

```text
all OK
```

Folder structure for the next steps:

```text
C:\GAMS_lecture\webapp\
    mixing_model.py
    plot_mixing.py
    app_step4.py  app_step5.py  app_step6.py
    app.py
    templates\index.html
```

---

<!-- slide: layout=code -->
# Step 2 – Model as a reusable function

`mixing_model.py` – Example 3 wrapped in a function with **inputs → results dictionary**:

```python
def solve_mixing(water_limit=0.25, cost1=80.0, cost2=60.0, amount=1.0):
    m = gp.Container()                 # new container for every call
    ...                                # sets, parameters, x(f), spec(c), balance
    mixing.solve()

    if "Optimal" not in mixing.status.name:
        return {"ok": False, "status": mixing.status.name}
    x1, x2 = x.records["level"]
    return {"ok": True, "cost": mixing.objective_value,
            "feed1": x1, "feed2": x2, ...}
```

✅ **TEST** – `python mixing_model.py`

```text
{'ok': True, 'status': 'OptimalGlobal', 'water_limit': 0.25, 'cost': 71.666..., 'feed1': 0.583..., 'feed2': 0.416..., ...}
{'ok': False, 'status': 'InfeasibleNoSolution', 'water_limit': 0.15}
```

Note:
Why a function? The web server calls it with different inputs for every request.
A dictionary is easy to send to the browser as JSON.

---

<!-- slide: layout=two-column, right=image(assets/figures/example3_whatif.png) -->
# Step 3 – What-if chart with Matplotlib

`plot_mixing.py` – solve for water limits 20 … 32 % and draw **two charts**:

```python
import matplotlib
matplotlib.use("Agg")          # no window – draw to file / memory
import matplotlib.pyplot as plt

res = sweep(limits)            # 13 GAMSPy solves
ax1.plot(lim, [r["cost"]  for r in res])                     # cost
ax2.plot(lim, [r["feed1"] for r in res], label="Feed 1")    # feed amounts
ax2.plot(lim, [r["feed2"] for r in res], label="Feed 2")
fig.savefig("mixing_whatif.png")
```

✅ **TEST** – `python plot_mixing.py` → open `mixing_whatif.png`

Note:
Two separate charts on purpose: cost (cent/kg) and amounts (kg) have different units –
never put them on one chart with two y-axes.
`@lru_cache` remembers the 13 solves for each cost combination, so the web page stays fast.

---

<!-- slide: layout=code -->
# Step 4 – The smallest Flask app

`app_step4.py`

```python
from flask import Flask
app = Flask(__name__)

@app.route("/")
def home():
    return "<h1>Hello from Flask!</h1>"

if __name__ == "__main__":
    app.run(debug=True)
```

✅ **TEST** – `python app_step4.py`, open **http://127.0.0.1:5000**

Stop the server with **Ctrl + C** before the next step.

Note:
`@app.route("/")` connects a URL with a Python function. `debug=True` restarts the
server automatically when you save a change.

---

<!-- slide: layout=code -->
# Step 5 – A form that solves the model

`app_step5.py` – the browser sends a number, Flask calls GAMSPy:

```python
from flask import Flask, request, render_template_string
from mixing_model import solve_mixing

PAGE = """
<form method="post">
  Max. water content [%]: <input name="water" type="number" value="{{ water }}">
  <button>Solve</button>
</form>
{% if r.ok %} <p>Minimum cost: <b>{{ "%.2f"|format(r.cost) }} cent/kg</b></p>
{% else %}    <p>No feasible mixture ({{ r.status }})</p> {% endif %}
"""

@app.route("/", methods=["GET", "POST"])
def home():
    water = float(request.form.get("water", 25))
    return render_template_string(PAGE, water=water,
                                  r=solve_mixing(water_limit=water / 100))
```

✅ **TEST** – enter **22** → `76.67 cent/kg`; enter **15** → *No feasible mixture*

---

<!-- slide: layout=code -->
# Step 6 – Add the Matplotlib chart

`app_step6.py` – a second route returns the chart as a **PNG image**:

```python
import io
from flask import Response
from plot_mixing import make_figure
import matplotlib.pyplot as plt

@app.route("/plot.png")
def plot_png():
    water = float(request.args.get("water", 25))
    fig = make_figure(current=solve_mixing(water_limit=water / 100))
    buf = io.BytesIO()
    fig.savefig(buf, format="png")       # save into memory, not to disk
    plt.close(fig)                       # free memory
    return Response(buf.getvalue(), mimetype="image/png")
```

In the page: `<img src="/plot.png?water={{ water }}">`

✅ **TEST** – open **http://127.0.0.1:5000/plot.png?water=22** directly, then the main page

---

<!-- slide: layout=code -->
# Step 7 – Interactive page: JSON API

`app.py` – two data routes + one page:

```python
@app.route("/")
def index():
    return render_template("index.html", feeds=FEEDS)

@app.route("/api/solve")                 # results as JSON
def api_solve():
    water, cost1, cost2 = read_inputs()
    return jsonify(solve_mixing(water_limit=water, cost1=cost1, cost2=cost2))

@app.route("/plot.png")                  # chart as PNG (as in step 6)
def plot_png(): ...
```

✅ **TEST** – open **http://127.0.0.1:5000/api/solve?water=25&cost1=80&cost2=60**

```json
{ "cost": 71.67, "feed1": 0.583, "feed2": 0.417, "ok": true,
  "status": "OptimalGlobal", "water": 0.25, "water_limit": 0.25 }
```

---

<!-- slide: layout=code -->
# Step 7 – Interactive page: sliders + JavaScript

`templates/index.html` – sliders call the API on every change:

```html
<input id="water" type="range" min="15" max="35" step="0.5" value="25">
<input id="cost1" type="range" min="40" max="120" value="80">
<input id="cost2" type="range" min="40" max="120" value="60">
<img id="plot">
```

```javascript
async function update() {
  const q = new URLSearchParams({ water: water.value,
                                  cost1: cost1.value, cost2: cost2.value });
  const r = await (await fetch("/api/solve?" + q)).json();   // GAMSPy
  document.getElementById("cost").textContent = r.cost.toFixed(2);
  document.getElementById("plot").src = "/plot.png?" + q;    // Matplotlib
}
```

✅ **TEST** – `python app.py`, move the sliders – numbers and chart update

---

<!-- slide: layout=image-full, image=assets/screenshots/webapp_screenshot.png -->
# The result

![Interactive mixing optimizer](../assets/screenshots/webapp_screenshot.png)

- **Sliders:** water limit, cost of feed 1 and feed 2
- **Cards:** minimum cost, feed ratio (bar), water in product
- **Chart:** what-if analysis with the current case marked
- Infeasible input (< 20 % water) → red warning instead of numbers

Note:
Live demo ideas: set feed 1 cheaper than feed 2 (70 vs 90) – the water limit is no
longer active and only feed 1 is used. Then move the water limit below 20 %.

---

<!-- slide: layout=bullets -->
# Summary & next steps

| Layer | Tool | Our file |
|-------|------|----------|
| Optimization model | **GAMSPy** | `mixing_model.py` |
| Visualization | **Matplotlib** | `plot_mixing.py` |
| Web server | **Flask** | `app.py` |
| User interface | HTML + JavaScript | `templates/index.html` |

**Ideas to continue**
- Add a third feed or a minimum MEA content – only `mixing_model.py` changes
- Read feed data from Excel with `pandas.read_excel`
- Deploy the app for students (e.g. a university server, or GAMS MIRO for a ready-made UI)

Note:
The same pattern works for any GAMSPy model: function → JSON route → page.
