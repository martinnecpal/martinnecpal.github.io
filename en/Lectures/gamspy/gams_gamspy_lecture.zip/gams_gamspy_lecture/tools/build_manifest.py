"""Build slides.json from the Markdown files in ../slides.

Run from the package root:   python tools/build_manifest.py
Re-run after every edit of a slide file, so slides.json stays in sync.

Each slide in slides.json:
  id, file, section, index, title, layout, hints (dict), markdown (slide body
  without hint comment and notes), notes, images (paths/URLs mentioned in the slide)
"""
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SLIDES = ROOT / "slides"

HINT = re.compile(r"<!--\s*slide:\s*(.*?)-->", re.S)
COMMENT = re.compile(r"<!--.*?-->", re.S)
MDIMG = re.compile(r"!\[[^\]]*\]\(([^)]+)\)")
HINTIMG = re.compile(r"image\(([^)]+)\)")


def split_frontmatter(text):
    if text.startswith("---\n"):
        end = text.index("\n---\n", 4)
        meta = {}
        for line in text[4:end].splitlines():
            if ":" in line:
                k, v = line.split(":", 1)
                meta[k.strip()] = v.strip().strip('"')
        return meta, text[end + 5:]
    return {}, text


def split_slides(body):
    """Split on lines that are exactly '---', ignoring fenced code blocks."""
    slides, cur, fenced = [], [], False
    for line in body.splitlines():
        if line.strip().startswith("```"):
            fenced = not fenced
        if line.strip() == "---" and not fenced:
            slides.append("\n".join(cur))
            cur = []
        else:
            cur.append(line)
    slides.append("\n".join(cur))
    return [s.strip() for s in slides if s.strip()]


def parse_hints(raw):
    hints = {}
    for part in re.split(r",\s*(?![^()\[\]]*[)\]])", raw.strip()):
        if "=" in part:
            k, v = part.split("=", 1)
            hints[k.strip()] = v.strip()
        elif part.strip():
            hints[part.strip()] = True
    return hints


def main():
    out = []
    for f in sorted(SLIDES.glob("*.md")):
        meta, body = split_frontmatter(f.read_text(encoding="utf-8"))
        n = 0
        for chunk in split_slides(body):
            m = HINT.search(chunk)
            if not m:              # file-level comments (conversion notes) only
                if not COMMENT.sub("", chunk).strip():
                    continue
            n += 1
            hints = parse_hints(m.group(1)) if m else {}
            notes = ""
            if "\nNote:" in "\n" + chunk:
                chunk, notes = re.split(r"(?m)^Note:\s*$", chunk, maxsplit=1)
            images = set(MDIMG.findall(chunk))
            for k, v in hints.items():
                if isinstance(v, str):
                    images.update(HINTIMG.findall(v))
                    if k in ("image", "photo"):
                        images.add(v)
            images = sorted({i.strip().removeprefix("../") for i in images})
            md = HINT.sub("", chunk)
            md = re.sub(r"<!--\s*CONVERSION NOTES.*?-->", "", md, flags=re.S).strip()
            title = next((l[2:].strip() for l in md.splitlines() if l.startswith("# ")), "")
            out.append({
                "id": f"{f.stem}-{n:02d}",
                "file": f"slides/{f.name}",
                "section": meta.get("section", ""),
                "index": len(out) + 1,
                "title": title,
                "layout": hints.get("layout", "default"),
                "hints": hints,
                "markdown": md,
                "notes": notes.strip(),
                "images": images,
            })
    (ROOT / "slides.json").write_text(json.dumps(out, ensure_ascii=False, indent=2),
                                      encoding="utf-8")
    print(f"{len(out)} slides written to slides.json")


if __name__ == "__main__":
    main()
