# TODO before the lecture

## Placeholders in the slide text

| File | Placeholder |
|------|-------------|
| `00_title_about_me.md` | `[ERASMUS+ / CEEPUS]`, `[HOST UNIVERSITY]`, `[DATE]` |
| `09_summary_closing.md` | `[ERASMUS+ / CEEPUS]`, `[HOST UNIVERSITY]`, link to course code `[TODO]` |
| `00_title_about_me.md` | check the job title ("University lecturer" is taken from martinnecpal.aiplaces.org) |

Search for `[` + capital letters and `TODO` in `slides/` to find all of them.

## Images to add (not included in the package)

| Target file | Slide | What |
|-------------|-------|------|
| `assets/photos/profile.png` | About me | download from https://www.martinnecpal.aiplaces.org/assets/images/profile.png |
| `assets/logos/` | title, acknowledgements | STU, MTF STU, host university, Erasmus+ or CEEPUS, GAMS, GAMSPy logos – official sources |
| `assets/screenshots/gams_studio_example01.png` | 03 – Running it in GAMS Studio | own screenshot: Example01.gms + Example01.lst tabs |
| `assets/screenshots/vscode_download.png` | 05 – Step 1 | code.visualstudio.com download page |
| `assets/screenshots/vscode_python_extension.png` | 05 – Step 2 | Extensions view, "Python" by Microsoft |
| `assets/screenshots/vscode_select_interpreter.png` | 05 – Step 4 | Command Palette → Python: Select Interpreter |
| `assets/screenshots/vscode_run_button.png` | 05 – Step 6 | ▶ Run Python File button + terminal output |
| GAMS Studio screenshots (6) | 02 | either download from gams.com (URLs in `assets/IMAGE_SOURCES.md`) or – better – take own screenshots of the current GAMS Studio |
| optional pictures | 01 – chemical / mechanical slides | process flowsheet, gear or machine part (own photos e.g. from the lab) |

## Check on the lecture computer

- [ ] GAMS + GAMS Studio installed, `Example01.gms` runs
- [ ] `.gamspy_venv` with `pip install -r code/requirements.txt`
- [ ] `python code/gamspy/test_gamspy.py` prints `ModelStatus.OptimalGlobal 1.0`
- [ ] `python code/webapp/app.py` opens at http://127.0.0.1:5000
- [ ] deck works offline
