# From GAMS to GAMSPy – lecture package

Source material for the lecture **"From GAMS to GAMSPy: optimization modelling in Python –
from model to interactive web page"** by Martin Necpal (MTF STU Trnava).

This package contains **no finished presentation**. It contains everything needed to build one
as a **React (HTML) slide deck**: slide texts, speaker notes, layout hints, figures, screenshots,
tested source code and instructions.

- Slides: **81** in **10 files** (`slides/`), also as one machine-readable file `slides.json`
- Everything was tested on **15 October 2026** with GAMS 54.6.0, GAMSPy 1.29.0, Python 3.13,
  Matplotlib 3.11 and Flask 3.1

---

## Folder structure

```text
gams_gamspy_lecture/
├── README.md                  ← this file
├── PRESENTATION_GUIDE.md      ← how to turn the slides into a React deck (layouts, design, notes)
├── TODO.md                    ← what must be filled in / captured before the lecture
├── slides.json                ← all slides as JSON (generated from slides/*.md)
│
├── slides/                    ← SOURCE OF TRUTH – edit these
│   ├── 00_title_about_me.md          title, about me, agenda            (3 slides)
│   ├── 01_gams_introduction.md       what GAMS is, history, use cases  (11)
│   ├── 02_gams_installation_studio.md  installing GAMS, GAMS Studio     (8)
│   ├── 03_gams_example1.md           Example 1 in GAMS                  (8)
│   ├── 04_gamspy_installation.md     Python + GAMSPy on Windows         (9)
│   ├── 05_vscode_setup.md            VS Code + Python environment       (7)
│   ├── 06_gamspy_example1.md         Example 1 in GAMSPy                (8)
│   ├── 07_gamspy_example3.md         Example 3 – mixing of streams      (11)
│   ├── 08_gamspy_webapp.md           Matplotlib + Flask web app, 7 steps (12)
│   └── 09_summary_closing.md         summary, acknowledgements, Q&A     (4)
│
├── assets/
│   ├── figures/               ← charts and diagrams made for the lecture (PNG + SVG)
│   ├── screenshots/           ← screenshot of the finished web app (+ place for your own)
│   └── IMAGE_SOURCES.md       ← every image: file, slide, origin, licence note
│
├── code/                      ← all code shown on the slides – runnable
│   ├── README.md              ← how to run each part
│   ├── requirements.txt
│   ├── gams/                  Example01.gms + real listing file Example01.lst
│   ├── gamspy/                Example 1 and 3 in GAMSPy, test script, exports
│   ├── webapp/                Flask app – steps 2–7 of section 6
│   └── figures/               make_figures.py – regenerates assets/figures
│
├── tools/
│   └── build_manifest.py      ← regenerates slides.json after editing slides/*.md
│
└── references/
    └── SOURCES.md             ← all web sources and the original lecture this builds on
```

## Lecture outline (≈ 90–120 min)

| # | Section | File | Slides | Time |
|---|---------|------|--------|------|
| 0 | Opening – title, about me, agenda | 00 | 3 | 5 min |
| 1 | Introduction to GAMS | 01, 02 | 19 | 20 min |
| 2 | Example 1 in GAMS (live in GAMS Studio) | 03 | 8 | 15 min |
| 3 | From GAMS to GAMSPy – installation, VS Code | 04, 05 | 16 | 15 min |
| 4 | Example 1 in GAMSPy | 06 | 8 | 10 min |
| 5 | Example 3 – mixing of streams (sets, parameters, what-if) | 07 | 11 | 15 min |
| 6 | From model to web page – Matplotlib + Flask (live demo) | 08 | 12 | 20 min |
| 7 | Summary, acknowledgements, Q&A | 09 | 4 | 10 min |

Sections 1 (installation slides) and 3 can be shortened if students installed everything beforehand.

## Workflow

1. Edit text in `slides/*.md` (the source of truth).
2. Run `python tools/build_manifest.py` → refreshes `slides.json`.
3. Build the React deck from `slides.json` + `assets/` following `PRESENTATION_GUIDE.md`.
4. Work through `TODO.md` (placeholders, logos, own screenshots).

## Credits

Examples 1 and 3 are adapted from the Erasmus+ lecture of **Prof. Elvis Ahmetović**
(University of Tuzla), *Mathematical modelling in GAMS*, STU, November 2025.
Example 3 problem: M. R. Eden, *Process Synthesis, Simulation and Optimization*, 2011.
See `references/SOURCES.md`.
