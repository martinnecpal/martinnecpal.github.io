# Presentation guide – building the React deck

This file tells whoever builds the deck (you, or an AI assistant you hand this package to)
how to turn `slides/*.md` / `slides.json` into a React HTML presentation.
**The deck itself is not part of this package.**

---

## 1. Slide source format

Every file in `slides/` has the same structure:

```markdown
---
title: "…"            # file title
section: "3 · …"      # section shown in the deck footer / progress bar
slide_separator: "---"
---

<!-- CONVERSION NOTES … -->          ← notes for the builder, not a slide

<!-- slide: layout=two-column, right=image(assets/figures/x.svg) -->
# Slide title
Slide body in Markdown (lists, **bold**, tables, ```code```).

Note:
Speaker notes – everything after a line "Note:" until the next ---

---

<!-- slide: layout=code -->
# Next slide
```

Rules:

| Element | Meaning |
|---------|---------|
| line `---` (outside code blocks) | slide break |
| `<!-- slide: key=value, … -->` | layout hints (see section 3) |
| first `# Heading` | slide title |
| `## Heading` | subtitle (title / section slides) |
| `Note:` … | speaker notes – never shown on the slide |
| `<!-- left column -->` / `<!-- right column -->` | split point for `code-compare` |
| other `<!-- … -->` | builder hints (e.g. optional figure), not shown |
| `[PLACEHOLDER]` in square brackets | text to fill in (see `TODO.md`) |
| `<small>…</small>` | small credit line |

`slides.json` contains the same information already parsed – one object per slide:

```json
{
  "id": "07_gamspy_example3-02",
  "file": "slides/07_gamspy_example3.md",
  "section": "5 · GAMSPy – sets, parameters and data",
  "index": 56,
  "title": "The problem",
  "layout": "two-column",
  "hints": { "layout": "two-column", "right": "image(assets/figures/example3_mixer.svg)" },
  "markdown": "# The problem\n\nTwo feed streams …",
  "notes": "…",
  "images": ["assets/figures/example3_mixer.svg"]
}
```

Regenerate it after any edit: `python tools/build_manifest.py`.

---

## 2. Recommended React setup

- **Vite + React** (single-page app, builds to static HTML/JS/CSS).
- Markdown rendering: `react-markdown` + `remark-gfm` (tables) + a syntax highlighter
  (`rehype-highlight` or `prism-react-renderer`).
  Languages used: `gams`, `python`, `powershell`, `html`, `javascript`, `json`, `text`.
  GAMS has no standard highlighter grammar – render as plain text or add a small custom
  grammar (keywords: `Set Parameter Table Scalar Variable Variables Positive Free Equation
  Equations Model Solve using maximizing minimizing Display option sum`, operators `=e= =l= =g= ..`).
- Import `slides.json` directly; copy `assets/` into `public/assets/` so paths like
  `assets/figures/x.svg` resolve unchanged.
- Fixed **16:9 stage (1920 × 1080)**, scaled to the window with CSS `transform: scale()`.

### Required deck features

| Feature | Behaviour |
|---------|-----------|
| Navigation | → / Space / PageDown next, ← / PageUp previous, Home / End, click |
| URL | `#/56` – deep link to slide index, survives reload |
| Progress | thin progress bar + footer: section name · slide n / 81 |
| Speaker view | key **S** opens a second window: current + next slide, notes, timer |
| Overview | key **O** – grid of all slides, click to jump |
| Fullscreen | key **F** |
| Print / PDF | `?print` → all slides stacked, one per page (`@page { size: 1920px 1080px }`) |
| Code | monospace ≥ 22 px on the 1920 stage; long blocks scroll inside the slide, never overflow |

---

## 3. Layouts

Map `layout` → React component. Hints that name a side (`left=`, `right=`) say what goes there;
the rest of the Markdown fills the other side.

| layout | Used for | Arrangement |
|--------|----------|-------------|
| `title` | 00 – first slide | big title + subtitle, author block, logo row (`logos=[…]`) at the bottom |
| `section-title` | first slide of each section | large section number + title, accent background |
| `agenda` | 00 – agenda | numbered list, highlight current section when reused |
| `two-column` | most content slides | text left, image right (or as given by `left=` / `right=`); 55 / 45 split |
| `steps` | installation / how-to | numbered list rendered as step cards; optional image right |
| `code` | code-centred slides | code full width; text above/below; optional small image right |
| `code-left` | 03 – GAMS code | code left 60 %, explanation right |
| `code-compare` | 06 – GAMS vs GAMSPy | two code blocks side by side, split at `<!-- left/right column -->` |
| `table` | dictionaries, shortcuts | one large readable table, zebra rows |
| `timeline` | 01 – history | table rows rendered as a horizontal timeline |
| `four-cards` | 01 – ecosystem | table rows rendered as 4 cards (product + purpose) |
| `icons-grid` | 01 – where used | list items as a 2×3 grid of tiles with a simple icon each |
| `diagram` | 01 – how GAMS works; 08 – architecture | 01: build the 4-box flow as a component; 08: use `assets/figures/webapp_architecture.svg` |
| `image-full` | 02 – Studio at a glance; 08 – result | image as large as possible, table/bullets as caption below |
| `bullets` | summaries, exercises | bullet list, large type |
| `references` | link lists | small type, clickable links |
| `summary` | 09 – what we learned | comparison table |
| `acknowledgements` | 09 | credits + logo row |
| `closing` | last slide | "Thank you" + contact |
| `default` | fallback | title + Markdown |

`photo=` (about me) → round or rounded-square portrait left, text right.

---

## 4. Visual design

Keep the deck consistent with the figures in `assets/figures/` (they use these colours):

| Token | Value | Use |
|-------|-------|-----|
| `--page` | `#f9f9f7` | slide background |
| `--surface` | `#fcfcfb` | cards, code background alternative |
| `--line` | `#e4e3df` | borders, table rules |
| `--ink` | `#0b0b0b` | titles, body text |
| `--ink2` | `#52514e` | secondary text, captions |
| `--blue` | `#2a78d6` | primary accent, series 1, Feed 1 |
| `--orange` | `#eb6834` | series 2, Feed 2, GAMS ↔ GAMSPy contrast |
| `--aqua` | `#1baf7a` | optimum points, "✅" results |
| `--critical` | `#d03b3b` | errors, infeasible |
| GAMS brand | `#f39200` (approx.) | only for GAMS logo context – optional |

- Font: a clean sans (e.g. Inter, Source Sans 3) for text; JetBrains Mono / Fira Code for code.
- Title 64–72 px, body 32–36 px, tables 26–28 px, code 22–26 px on the 1920 stage.
- One idea per slide; at most ~7 bullets; never shrink text to fit – split the slide instead.
- `✅ TEST` boxes (section 6) → a green-bordered callout; `⚠` lines → amber callout.
- Emoji used in the text (✅ ⚠ ➡ 🔵 🔴 🟢 ✉ 🌐) may be replaced by icons (e.g. lucide-react).
- Section colour: optional thin accent bar per section in the footer.

---

## 5. Live demo points (keep the deck short there)

| Slide (id) | Live action |
|------------|-------------|
| 03_gams_example1-06 | run Example01.gms in GAMS Studio; delete a `;` to show an error |
| 04_gamspy_installation-03…08 | install GAMSPy (or show pre-installed environment) |
| 06_gamspy_example1-05 | run `code/gamspy/example01_gams_style.py` in VS Code |
| 07_gamspy_example3-10 | run `code/gamspy/example03_indexed.py` – what-if table |
| 08_gamspy_webapp-04…10 | run each step from `code/webapp/` |
| 08_gamspy_webapp-11 | `python app.py` → move sliders (demo ideas in the speaker notes) |

Optionally embed the running Flask app (`http://127.0.0.1:5000`) in an `<iframe>` on slide
`08_gamspy_webapp-11` with the screenshot as fallback when the server is not running.

---

## 6. Quality checklist for the built deck

- [ ] all 81 slides present, in `index` order, titles match `slides.json`
- [ ] no text or code overflows the 16:9 stage (check every `code` slide)
- [ ] every `images` entry renders or is a deliberate TODO placeholder box
- [ ] speaker notes visible only in speaker view
- [ ] tables readable from the back of the room (≥ 26 px)
- [ ] works offline (fonts and libraries bundled, no CDN at lecture time)
- [ ] print / PDF export gives 81 pages
