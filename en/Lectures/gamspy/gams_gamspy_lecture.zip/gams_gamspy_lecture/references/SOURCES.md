# Sources

## Original lecture this builds on
- E. Ahmetović: *Mathematical modelling in General Algebraic Modelling System (GAMS)*,
  Erasmus+ lecture, Slovak University of Technology in Bratislava, November 2025
  (PDF in the "Gams Lectures" project – Examples 1 and 3, transport model).
- M. R. Eden: *Process Synthesis, Simulation and Optimization*, 2011 – mixing of streams (Example 3).
- A. Brooke, D. Kendrick, A. Meeraus, R. Raman: *GAMS – A User's Guide*, GAMS Development Corp.

## GAMS
- GAMS homepage, products and case studies – https://www.gams.com/
- GAMS download – https://www.gams.com/download/
- GAMS Model Library – https://www.gams.com/latest/gamslib_ml/libhtml/
- NOA library (Andrei, *Nonlinear Optimization Applications Using the GAMS Technology*) –
  https://www.gams.com/latest/noalib_ml/libhtml/
- Solver manuals / model types – https://www.gams.com/latest/docs/S_MAIN.html
- GAMS Studio manual – https://www.gams.com/latest/docs/T_STUDIO.html
- Using GAMS Studio (tutorial by B. McCarl) – https://www.gams.com/latest/docs/UG_studio_tutorial.html
- History of GAMS – https://en.wikipedia.org/wiki/General_algebraic_modeling_system
- Alexander Meeraus, INFORMS biography –
  https://www.informs.org/Explore/History-of-O.R.-Excellence/Biographical-Profiles/Meeraus-Alexander

## GAMSPy
- Documentation – https://gamspy.readthedocs.io/en/latest/
- Installation and licensing – https://gamspy.readthedocs.io/en/latest/user/installation.html
- GAMSPy for GAMS users – https://gamspy.readthedocs.io/en/latest/user/gamspy_for_gams_users.html
- Examples – https://github.com/GAMS-dev/gamspy-examples

## Tools
- Visual Studio Code – https://code.visualstudio.com/
- VS Code Python tutorial – https://code.visualstudio.com/docs/python/python-tutorial
- Python – https://www.python.org/downloads/
- Matplotlib – https://matplotlib.org/
- Flask – https://flask.palletsprojects.com/

## Author
- Martin Necpal – https://www.martinnecpal.aiplaces.org/en/
