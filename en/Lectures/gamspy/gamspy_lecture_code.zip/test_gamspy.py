import gamspy as gp

# gams container definition
m = gp.Container() 

# variable definition
x = gp.Variable(m, 'x')

# equation definition 
e1 = gp.Equation(m, 'e1')
e1[...] = x >=1

# objective definition
objective = x

# model definition and solve 
model = gp.Model(m,'test',equations=m.getEquations(),problem='LP',sense='min',objective=x)
model.solve()

# print result 
print(model.objective_value)
