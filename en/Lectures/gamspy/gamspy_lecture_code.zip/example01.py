"""Simple LP optimisation problem (GAMSPy translation of Example01.gms)."""

import sys
import gamspy as gp

# gams container definition
m = gp.Container()

# variable definition
x1 = gp.Variable(m, name="x1", type="positive")
x2 = gp.Variable(m, name="x2", type="positive")
z = gp.Variable(m, name="z", type='free')

# equation definition 
eq1 = gp.Equation(m, name="eq1")
eq2 = gp.Equation(m, name="eq2")
eq1[...] = x1 + 3 * x2 <= 4
eq2[...] = x1 + x2 <= 2

# objective definition
objective = gp.Equation(m, "obj")
objective[...] = z == 3 * x1 + 2 * x2

primjer01 = gp.Model(
        m,
        name="Primjer01",
        equations = m.getEquations(),
        problem = "LP",
        sense = gp.Sense.MAX,
        objective = z,
    )

primjer01.solve(output=sys.stdout)

print("x1.l =", x1.toValue())
print("x2.l =", x2.toValue())
print("Z.l  =", primjer01.objective_value)