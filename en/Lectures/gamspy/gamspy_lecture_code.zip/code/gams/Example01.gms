$Title Simple LP optimisation problem
* Example 1 (after Prof. E. Ahmetovic, University of Tuzla)
*   max  Z = 3*x1 + 2*x2
*   s.t. x1 + 3*x2 <= 4
*        x1 +   x2 <= 2
*        x1, x2 >= 0

Positive Variables x1, x2;
Free Variable      Z;

Equations obj, eq1, eq2;

obj..  Z =e= 3*x1 + 2*x2;
eq1..  x1 + 3*x2 =l= 4;
eq2..  x1 +   x2 =l= 2;

Model Example01 /all/;
Solve Example01 maximizing Z using LP;

Display x1.l, x2.l, Z.l;
