"""Step 3 - What-if analysis of Example 3 plotted with Matplotlib.

Run directly to test:   python plot_mixing.py   -> creates mixing_whatif.png
"""
import numpy as np
import matplotlib
matplotlib.use("Agg")            # draw to files/memory, no window needed (also for Flask)
import matplotlib.pyplot as plt

plt.rcParams.update({"font.size": 11, "axes.titlesize": 13})

from functools import lru_cache
from mixing_model import sweep

BLUE, ORANGE = "#2a78d6", "#eb6834"
INK, INK2, GRID = "#0b0b0b", "#52514e", "#e4e3df"


@lru_cache(maxsize=32)
def what_if(cost1, cost2):
    """Solve for water limits 20-32 % once per cost combination (cached)."""
    limits = np.round(np.arange(0.20, 0.3201, 0.01), 2)
    return tuple(r for r in sweep(limits, cost1=cost1, cost2=cost2) if r["ok"])


def make_figure(cost1=80.0, cost2=60.0, current=None):
    """Two charts: minimum cost and feed amounts vs. the water limit."""
    res = what_if(cost1, cost2)
    lim = [r["water_limit"] * 100 for r in res]

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(10, 3.8), dpi=110)
    fig.patch.set_facecolor("#fcfcfb")

    # Chart 1 - minimum cost (one series -> no legend, the title names it)
    ax1.plot(lim, [r["cost"] for r in res], color=BLUE, lw=2,
             marker="o", ms=5)
    ax1.set_title("Minimum cost of 1 kg mixture", color=INK, loc="left")
    ax1.set_ylabel("cent / kg", color=INK2)

    # Chart 2 - feed amounts (two series -> legend + direct labels)
    ax2.plot(lim, [r["feed1"] for r in res], color=BLUE, lw=2, marker="o",
             ms=5, label="Feed 1 (80 % MEA)")
    ax2.plot(lim, [r["feed2"] for r in res], color=ORANGE, lw=2, marker="s",
             ms=5, label="Feed 2 (68 % MEA)")
    ax2.set_title("Optimal feed amounts", color=INK, loc="left")
    ax2.set_ylabel("kg per 1 kg mixture", color=INK2)
    ax2.legend(frameon=False, loc="upper center", fontsize=10)

    for ax in (ax1, ax2):
        ax.set_xlabel("Max. water content in product [%]", color=INK2)
        ax.grid(True, color=GRID, lw=0.8)
        ax.set_axisbelow(True)
        for side in ("top", "right"):
            ax.spines[side].set_visible(False)
        for side in ("left", "bottom"):
            ax.spines[side].set_color("#b5b4ae")
        ax.tick_params(colors=INK2, labelsize=10)
        ax.set_facecolor("#fcfcfb")

    # Highlight the currently selected case
    if current and current["ok"]:
        x = current["water_limit"] * 100
        ax1.axvline(x, color=INK2, lw=1, ls="--")
        ax1.annotate(f'{current["cost"]:.2f} cent/kg',
                     (x, current["cost"]), xytext=(8, 8),
                     textcoords="offset points", color=INK, fontsize=10)
        ax2.axvline(x, color=INK2, lw=1, ls="--")

    fig.tight_layout()
    return fig


if __name__ == "__main__":
    from mixing_model import solve_mixing
    fig = make_figure(current=solve_mixing(0.25))
    fig.savefig("mixing_whatif.png")
    print("Saved mixing_whatif.png")
