"""Step 7 - interactive web app for Example 3 (GAMSPy + Matplotlib + Flask).

Run:   python app.py
Open:  http://127.0.0.1:5000

Routes
  /            the page (templates/index.html)
  /api/solve   JSON results of one GAMSPy solve      e.g. /api/solve?water=25&cost1=80&cost2=60
  /plot.png    Matplotlib what-if chart as PNG       same parameters
"""
import io

from flask import Flask, Response, jsonify, render_template, request

from mixing_model import FEEDS, solve_mixing
from plot_mixing import make_figure      # sets the Agg backend first
import matplotlib.pyplot as plt

app = Flask(__name__)


def read_inputs():
    """Read and check the parameters from the URL."""
    water = float(request.args.get("water", 25))
    cost1 = float(request.args.get("cost1", 80))
    cost2 = float(request.args.get("cost2", 60))
    water = min(max(water, 0), 100)
    return water / 100, max(cost1, 0), max(cost2, 0)


@app.route("/")
def index():
    return render_template("index.html", feeds=FEEDS)


@app.route("/api/solve")
def api_solve():
    water, cost1, cost2 = read_inputs()
    return jsonify(solve_mixing(water_limit=water, cost1=cost1, cost2=cost2))


@app.route("/plot.png")
def plot_png():
    water, cost1, cost2 = read_inputs()
    current = solve_mixing(water_limit=water, cost1=cost1, cost2=cost2)
    fig = make_figure(cost1=cost1, cost2=cost2, current=current)
    buf = io.BytesIO()
    fig.savefig(buf, format="png")
    plt.close(fig)
    return Response(buf.getvalue(), mimetype="image/png")


if __name__ == "__main__":
    app.run(debug=True)
