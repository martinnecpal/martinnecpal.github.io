"""Step 2 - Example 3 (mixing of streams) as a reusable function.

Run directly to test:   python mixing_model.py
"""
import gamspy as gp

# Default data (after Prof. E. Ahmetovic; M. R. Eden, 2011)
FEEDS = {
    #          MEA   water  cost [cent/kg]
    "feed1": (0.80, 0.20, 80.0),
    "feed2": (0.68, 0.32, 60.0),
}


def solve_mixing(water_limit=0.25, cost1=80.0, cost2=60.0, amount=1.0):
    """Solve the mixing LP and return the results as a dictionary."""
    m = gp.Container()          # new container for every call

    f = gp.Set(m, "f", records=list(FEEDS))
    c = gp.Set(m, "c", records=["MEA", "water"])

    w = gp.Parameter(m, "w", domain=[f, c], records=[
        [feed, comp, frac]
        for feed, (mea, water, _) in FEEDS.items()
        for comp, frac in (("MEA", mea), ("water", water))
    ])
    cost = gp.Parameter(m, "cost", domain=f,
                        records=[["feed1", cost1], ["feed2", cost2]])
    wmax = gp.Parameter(m, "wmax", domain=c, records=[["water", water_limit]])
    M = gp.Parameter(m, "M", records=amount)

    x = gp.Variable(m, "x", type="positive", domain=f)

    spec = gp.Equation(m, "spec", domain=c)
    balance = gp.Equation(m, "balance")
    spec[c].where[wmax[c]] = gp.Sum(f, w[f, c] * x[f]) <= wmax[c] * M
    balance[...] = gp.Sum(f, x[f]) == M

    mixing = gp.Model(m, "mixing", equations=m.getEquations(),
                      problem="LP", sense="min",
                      objective=gp.Sum(f, cost[f] * x[f]))
    mixing.solve()

    status = mixing.status.name                 # e.g. "OptimalGlobal"
    if "Optimal" not in status:
        return {"ok": False, "status": status, "water_limit": water_limit}

    x1, x2 = (float(v) for v in x.records["level"])
    water = (FEEDS["feed1"][1] * x1 + FEEDS["feed2"][1] * x2) / amount
    return {
        "ok": True,
        "status": status,
        "water_limit": water_limit,
        "cost": float(mixing.objective_value),
        "feed1": x1,
        "feed2": x2,
        "water": water,
        "mea": 1 - water,
    }


def sweep(limits, **kwargs):
    """Solve the model for several water limits (what-if analysis)."""
    return [solve_mixing(water_limit=lim, **kwargs) for lim in limits]


if __name__ == "__main__":
    print(solve_mixing())                 # base case
    print(solve_mixing(water_limit=0.15)) # infeasible case
