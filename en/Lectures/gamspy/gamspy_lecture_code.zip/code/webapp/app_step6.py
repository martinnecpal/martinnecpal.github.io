"""Step 6 - form + GAMSPy + Matplotlib chart on the page.

Run:   python app_step6.py
Open:  http://127.0.0.1:5000
"""
import io

from flask import Flask, Response, request, render_template_string

from mixing_model import solve_mixing
from plot_mixing import make_figure   # sets the Agg backend first
import matplotlib.pyplot as plt

app = Flask(__name__)

PAGE = """
<h1>Mixing of streams – Example 3</h1>
<form method="post">
  Max. water content [%]:
  <input name="water" type="number" step="0.5" value="{{ water }}">
  <button type="submit">Solve</button>
</form>

{% if r.ok %}
  <p>Minimum cost: <b>{{ "%.2f"|format(r.cost) }} cent/kg</b> –
     Feed 1: {{ "%.3f"|format(r.feed1) }} kg, Feed 2: {{ "%.3f"|format(r.feed2) }} kg</p>
{% else %}
  <p style="color:#d03b3b">No feasible mixture ({{ r.status }})</p>
{% endif %}

<img src="/plot.png?water={{ water }}" width="900">
"""


@app.route("/", methods=["GET", "POST"])
def home():
    water = float(request.form.get("water", 25))
    return render_template_string(PAGE, water=water,
                                  r=solve_mixing(water_limit=water / 100))


@app.route("/plot.png")
def plot_png():
    """Matplotlib figure sent to the browser as a PNG image."""
    water = float(request.args.get("water", 25))
    fig = make_figure(current=solve_mixing(water_limit=water / 100))
    buf = io.BytesIO()
    fig.savefig(buf, format="png")
    plt.close(fig)                       # free memory after each request
    return Response(buf.getvalue(), mimetype="image/png")


if __name__ == "__main__":
    app.run(debug=True)
