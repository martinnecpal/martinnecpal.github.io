"""Step 5 - a web form that solves Example 3 with GAMSPy.

Run:   python app_step5.py
Open:  http://127.0.0.1:5000
"""
from flask import Flask, request, render_template_string

from mixing_model import solve_mixing

app = Flask(__name__)

PAGE = """
<h1>Mixing of streams – Example 3</h1>
<form method="post">
  Max. water content [%]:
  <input name="water" type="number" step="0.5" value="{{ water }}">
  <button type="submit">Solve</button>
</form>

{% if r and r.ok %}
  <p>Minimum cost: <b>{{ "%.2f"|format(r.cost) }} cent/kg</b></p>
  <p>Feed 1: {{ "%.3f"|format(r.feed1) }} kg &nbsp; Feed 2: {{ "%.3f"|format(r.feed2) }} kg</p>
{% elif r %}
  <p style="color:#d03b3b">No feasible mixture ({{ r.status }})</p>
{% endif %}
"""


@app.route("/", methods=["GET", "POST"])
def home():
    water = float(request.form.get("water", 25))
    result = solve_mixing(water_limit=water / 100)
    return render_template_string(PAGE, water=water, r=result)


if __name__ == "__main__":
    app.run(debug=True)
