"""Step 4 - the smallest Flask web page.

Run:   python app_step4.py
Open:  http://127.0.0.1:5000
"""
from flask import Flask

app = Flask(__name__)


@app.route("/")
def home():
    return "<h1>Hello from Flask!</h1><p>Our GAMSPy web app will live here.</p>"


if __name__ == "__main__":
    app.run(debug=True)
