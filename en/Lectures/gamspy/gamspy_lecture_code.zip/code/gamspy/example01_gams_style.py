"""Example 1 in GAMSPy - one-to-one translation of Example01.gms
(after Prof. E. Ahmetovic, University of Tuzla)
"""
import gamspy as gp

m = gp.Container()

# Positive Variables x1, x2;  Free Variable Z;
x1 = gp.Variable(m, "x1", type="positive")
x2 = gp.Variable(m, "x2", type="positive")
Z = gp.Variable(m, "Z", type="free")

# Equations obj, eq1, eq2;
obj = gp.Equation(m, "obj")
eq1 = gp.Equation(m, "eq1")
eq2 = gp.Equation(m, "eq2")

# obj.. Z =e= 3*x1 + 2*x2;  eq1.. ... =l= 4;  eq2.. ... =l= 2;
obj[...] = Z == 3 * x1 + 2 * x2
eq1[...] = x1 + 3 * x2 <= 4
eq2[...] = x1 + x2 <= 2

# Model Example01 /all/;
example01 = gp.Model(m, "example01", equations=m.getEquations(),
                     problem="LP", sense="max", objective=Z)

# Solve Example01 maximizing Z using LP;
summary = example01.solve()
print(summary)

# Display x1.l, x2.l, Z.l;
print("x1 =", x1.toValue(), " x2 =", x2.toValue(), " Z =", Z.toValue())

# Optional: write the model back as GAMS code (folder "exported")
# example01.toGams("exported")
