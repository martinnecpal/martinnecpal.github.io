"""Example 1 - simple LP in GAMSPy
(after Prof. E. Ahmetovic, University of Tuzla)

    max  Z = 3*x1 + 2*x2
    s.t. x1 + 3*x2 <= 4
         x1 +   x2 <= 2
         x1, x2 >= 0
"""
import gamspy as gp

# Container - holds all symbols (the "GAMS program")
m = gp.Container()

# Variables
x1 = gp.Variable(m, "x1", type="positive")
x2 = gp.Variable(m, "x2", type="positive")

# Equations: declare + define
eq1 = gp.Equation(m, "eq1")
eq2 = gp.Equation(m, "eq2")
eq1[...] = x1 + 3 * x2 <= 4
eq2[...] = x1 + x2 <= 2

# Model - objective written directly as an expression
example01 = gp.Model(
    m,
    "example01",
    equations=[eq1, eq2],
    problem="LP",
    sense="max",
    objective=3 * x1 + 2 * x2,
)

example01.solve()

# Results
print("Solver status :", example01.solve_status)
print("Model status  :", example01.status)
print("Objective Z   :", example01.objective_value)
print("x1 =", x1.toValue(), " x2 =", x2.toValue())
print("Marginals: eq1 =", eq1.records["marginal"][0],
      " eq2 =", eq2.records["marginal"][0])
