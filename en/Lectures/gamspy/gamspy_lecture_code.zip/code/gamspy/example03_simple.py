"""Example 3 - Mixing of streams (MEA / water), direct translation
(after Prof. E. Ahmetovic; source: M. R. Eden, Process Synthesis, Simulation and Optimization, 2011)

  min  z = 80*m1 + 60*m2                 cost of 1 kg mixture [cent]
  s.t. 0.20*m1 + 0.32*m2 <= 0.25         max. 25 mass.% water
       m1 + m2 = 1                       basis: 1 kg mixture
       m1, m2 >= 0
"""
import gamspy as gp

m = gp.Container()

m1 = gp.Variable(m, "m1", type="positive", description="mass of feed 1 [kg]")
m2 = gp.Variable(m, "m2", type="positive", description="mass of feed 2 [kg]")
z = gp.Variable(m, "z", type="free", description="cost of 1 kg mixture [cent]")

obj = gp.Equation(m, "obj", description="objective function")
water = gp.Equation(m, "water", description="water content in mixture")
balance = gp.Equation(m, "balance", description="total mass balance")

obj[...] = z == 80 * m1 + 60 * m2
water[...] = 0.20 * m1 + 0.32 * m2 <= 0.25
balance[...] = m1 + m2 == 1

mixing = gp.Model(m, "mixing", equations=m.getEquations(),
                  problem="LP", sense="min", objective=z)
mixing.solve()

print(f"z  = {z.toValue():.3f} cent/kg")
print(f"m1 = {m1.toValue():.3f} kg   m2 = {m2.toValue():.3f} kg")
