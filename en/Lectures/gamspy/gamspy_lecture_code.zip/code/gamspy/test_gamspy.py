"""Minimal test that GAMSPy and its default solver work."""
import gamspy as gp

m = gp.Container()
x = gp.Variable(m, "x")
e = gp.Equation(m, "e")
e[...] = x >= 1

model = gp.Model(m, "test", equations=[e],
                 problem="LP", sense="min", objective=x)
model.solve()

print(model.status, model.objective_value)   # ModelStatus.OptimalGlobal 1.0
