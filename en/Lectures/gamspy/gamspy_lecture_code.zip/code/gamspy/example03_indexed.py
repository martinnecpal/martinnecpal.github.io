"""Example 3 - Mixing of streams, general (indexed) formulation
(after Prof. E. Ahmetovic; source: M. R. Eden, 2011)

  min  sum(f, cost(f) * x(f))
  s.t. sum(f, w(f,c) * x(f)) <= wmax(c) * M   for every component c
       sum(f, x(f)) = M
       x(f) >= 0
"""
import pandas as pd
import gamspy as gp

m = gp.Container()

# ---- Sets -----------------------------------------------------------
f = gp.Set(m, "f", records=["feed1", "feed2"], description="feed streams")
c = gp.Set(m, "c", records=["MEA", "water"], description="components")

# ---- Data (parameters) ---------------------------------------------
composition = pd.DataFrame(
    [["feed1", "MEA", 0.80], ["feed1", "water", 0.20],
     ["feed2", "MEA", 0.68], ["feed2", "water", 0.32]],
    columns=["f", "c", "value"],
)
w = gp.Parameter(m, "w", domain=[f, c], records=composition,
                 description="mass fraction of component c in feed f [-]")
cost = gp.Parameter(m, "cost", domain=f,
                    records=[["feed1", 80], ["feed2", 60]],
                    description="feed cost [cent/kg]")
wmax = gp.Parameter(m, "wmax", domain=c, records=[["water", 0.25]],
                    description="max. mass fraction in product [-]")
M = gp.Parameter(m, "M", records=1, description="product amount [kg]")

# ---- Variables ------------------------------------------------------
x = gp.Variable(m, "x", type="positive", domain=f,
                description="mass of feed f in product [kg]")

# ---- Equations ------------------------------------------------------
spec = gp.Equation(m, "spec", domain=c, description="product specification")
balance = gp.Equation(m, "balance", description="total mass balance")

spec[c].where[wmax[c]] = gp.Sum(f, w[f, c] * x[f]) <= wmax[c] * M
balance[...] = gp.Sum(f, x[f]) == M

# ---- Model and solve -----------------------------------------------
mixing = gp.Model(m, "mixing", equations=m.getEquations(),
                  problem="LP", sense="min",
                  objective=gp.Sum(f, cost[f] * x[f]))
mixing.solve()

# ---- Results --------------------------------------------------------
print(f"Minimum cost: {mixing.objective_value:.3f} cent/kg")
print(x.records[["f", "level"]])

# Product composition = sum(f, w(f,c) * x(f)) / M
product = gp.Parameter(m, "product", domain=c)
product[c] = gp.Sum(f, w[f, c] * x.l[f]) / M
print(product.records)

# ---- What-if: different water limits ---------------------------------
print("\nwater limit | cost [cent/kg] | feed1 | feed2")
for limit in [0.20, 0.22, 0.25, 0.28, 0.32]:
    wmax.setRecords([["water", limit]])
    mixing.solve()
    x1, x2 = x.records["level"]
    print(f"   {limit:.2f}     |    {mixing.objective_value:7.3f}     | {x1:.3f} | {x2:.3f}")
