positive Variable x1;
positive Variable x2;
free Variable Z;
Equation obj;
Equation eq1;
Equation eq2;
Model example01 / obj,eq1,eq2 /;
$onMultiR
$gdxLoadAll "exported/example01_data.gdx"
$offMulti
obj .. Z =e= 3 * x1 + 2 * x2;
eq1 .. x1 + 3 * x2 =l= 4;
eq2 .. x1 + x2 =l= 2;
solve example01 using LP MAX Z;