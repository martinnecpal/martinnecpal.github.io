"""Figures for the lecture (run: python make_figures.py)."""
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon, FancyBboxPatch, FancyArrowPatch

BLUE, ORANGE, AQUA = "#2a78d6", "#eb6834", "#1baf7a"
INK, INK2, GRID, SURF = "#0b0b0b", "#52514e", "#e4e3df", "#fcfcfb"
plt.rcParams.update({"font.size": 12, "axes.titlesize": 14})

def style(ax):
    ax.set_facecolor(SURF); ax.grid(True, color=GRID, lw=0.8); ax.set_axisbelow(True)
    for s in ("top", "right"): ax.spines[s].set_visible(False)
    for s in ("left", "bottom"): ax.spines[s].set_color("#b5b4ae")
    ax.tick_params(colors=INK2)

# --- Example 1: feasible region -------------------------------------------
fig, ax = plt.subplots(figsize=(7, 5.2), dpi=150); fig.patch.set_facecolor(SURF); style(ax)
x = np.linspace(0, 4.5, 100)
ax.add_patch(Polygon([[0, 0], [2, 0], [1, 1], [0, 4/3]], closed=True,
                     facecolor=BLUE, alpha=0.15, edgecolor="none"))
ax.plot(x, (4 - x) / 3, color=BLUE, lw=2, label="x₁ + 3x₂ = 4")
ax.plot(x, 2 - x, color=ORANGE, lw=2, label="x₁ + x₂ = 2")
for z, ls in [(3, ":"), (6, "--")]:
    ax.plot(x, (z - 3 * x) / 2, color=INK2, lw=1.2, ls=ls)
ax.text(0.66, 0.62, "Z = 3", color=INK2, fontsize=10)
ax.text(1.3, 1.2, "Z = 6", color=INK2, fontsize=10)
pts = {"A": (0, 0), "B": (2, 0), "C": (1, 1), "D": (0, 4/3)}
for k, (px, py) in pts.items():
    ax.plot(px, py, "o", ms=9 if k == "B" else 7,
            color=AQUA if k == "B" else INK, mec=SURF, mew=2, zorder=5)
    ax.annotate(k, (px, py), xytext=(8, 6), textcoords="offset points",
                fontweight="bold", color=INK)
ax.annotate("Optimum B (2, 0)\nZ = 6", (2, 0), xytext=(2.6, 0.75),
            arrowprops=dict(arrowstyle="->", color=INK2), color=INK)
ax.text(0.3, 0.3, "feasible\nregion", color=BLUE, ha="center")
ax.set_xlim(0, 4.3); ax.set_ylim(0, 2.3)
ax.set_xlabel("x₁", color=INK2); ax.set_ylabel("x₂", color=INK2)
ax.set_title("Example 1 – graphical solution", loc="left", color=INK)
ax.legend(frameon=False, loc="upper right")
fig.tight_layout(); fig.savefig("example1_feasible_region.png"); fig.savefig("example1_feasible_region.svg")

# --- Example 3: graphical solution ---------------------------------------
fig, ax = plt.subplots(figsize=(7, 5.2), dpi=150); fig.patch.set_facecolor(SURF); style(ax)
m1 = np.linspace(0, 1.3, 100)
ax.plot(m1, 1 - m1, color=BLUE, lw=2, label="m₁ + m₂ = 1  (feasible line)")
ax.plot(m1, (0.25 - 0.20 * m1) / 0.32, color=ORANGE, lw=2, label="0.20 m₁ + 0.32 m₂ = 0.25")
ax.fill_between(m1, 0, (0.25 - 0.20 * m1) / 0.32, color=ORANGE, alpha=0.08)
ax.plot([7/12, 1], [5/12, 0], color=BLUE, lw=6, alpha=0.35, solid_capstyle="round")
ax.plot(7/12, 5/12, "o", ms=10, color=AQUA, mec=SURF, mew=2, zorder=5)
ax.annotate("Optimum: m₁ = 0.583, m₂ = 0.417\nz = 71.67 cent/kg", (7/12, 5/12),
            xytext=(0.72, 0.62), arrowprops=dict(arrowstyle="->", color=INK2), color=INK)
ax.plot(1, 0, "o", ms=7, color=INK, mec=SURF, mew=2)
ax.annotate("(1, 0): z = 80", (1, 0), xytext=(0.62, 0.04), color=INK2)
ax.set_xlim(0, 1.3); ax.set_ylim(0, 1.05)
ax.set_xlabel("m₁ – feed 1 [kg]", color=INK2); ax.set_ylabel("m₂ – feed 2 [kg]", color=INK2)
ax.set_title("Example 3 – feasible solutions lie on the thick segment", loc="left", color=INK)
ax.legend(frameon=False, loc="upper right")
fig.tight_layout(); fig.savefig("example3_graphical.png"); fig.savefig("example3_graphical.svg")

# --- Example 3: mixer diagram --------------------------------------------
fig, ax = plt.subplots(figsize=(9, 4), dpi=150); fig.patch.set_facecolor(SURF)
ax.set_xlim(0, 9); ax.set_ylim(0, 4); ax.axis("off")
def box(x, y, w, h, txt, col):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.05,rounding_size=0.15",
                                facecolor="white", edgecolor=col, lw=2))
    ax.text(x + w/2, y + h/2, txt, ha="center", va="center", color=INK, fontsize=11)
def arrow(a, b):
    ax.add_patch(FancyArrowPatch(a, b, arrowstyle="-|>", mutation_scale=18, color=INK2, lw=1.8))
box(0.2, 2.4, 2.4, 1.3, "Feed 1  (m₁ = ?)\n80 % MEA · 20 % water\n80 cent/kg", BLUE)
box(0.2, 0.3, 2.4, 1.3, "Feed 2  (m₂ = ?)\n68 % MEA · 32 % water\n60 cent/kg", ORANGE)
box(3.7, 1.35, 1.6, 1.3, "MIXER", INK2)
box(6.4, 1.35, 2.4, 1.3, "Product  m₃ = 1 kg\nwater ≤ 25 %\nmin. cost", AQUA)
arrow((2.6, 3.05), (3.7, 2.3)); arrow((2.6, 0.95), (3.7, 1.7)); arrow((5.3, 2.0), (6.4, 2.0))
fig.tight_layout(); fig.savefig("example3_mixer.png"); fig.savefig("example3_mixer.svg")

# --- Architecture diagram for the web app --------------------------------
fig, ax = plt.subplots(figsize=(10, 3.2), dpi=150); fig.patch.set_facecolor(SURF)
ax.set_xlim(0, 10); ax.set_ylim(0, 3.2); ax.axis("off")
items = [(0.2, "Browser\nsliders + JS", INK2), (3.0, "Flask\napp.py", BLUE),
         (5.6, "GAMSPy\nmixing_model.py", AQUA), (8.1, "Solver\nCPLEX", INK2)]
for x0, t, c in items: box(x0, 1.6, 1.8, 1.2, t, c)
box(3.0, 0.1, 1.8, 1.0, "Matplotlib\nplot_mixing.py", ORANGE)
arrow((2.0, 2.45), (3.0, 2.45)); arrow((3.0, 1.95), (2.0, 1.95))
arrow((4.8, 2.2), (5.6, 2.2)); arrow((7.4, 2.2), (8.1, 2.2)); arrow((3.9, 1.6), (3.9, 1.1))
ax.text(2.5, 2.6, "request", ha="center", fontsize=9, color=INK2)
ax.text(2.5, 1.62, "JSON + PNG", ha="center", fontsize=9, color=INK2)
fig.tight_layout(); fig.savefig("webapp_architecture.png"); fig.savefig("webapp_architecture.svg")
print("figures done")
