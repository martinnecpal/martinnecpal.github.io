# Code for the lecture

All files were run successfully with GAMS 54.6.0, GAMSPy 1.29.0, Python 3.13,
Matplotlib 3.11 and Flask 3.1 (15 October 2026).

## Setup (Windows, PowerShell)

```powershell
cd C:\GAMS_lecture\code
python -m venv .gamspy_venv
.gamspy_venv\Scripts\Activate.ps1
pip install -r requirements.txt
python gamspy\test_gamspy.py          # → ModelStatus.OptimalGlobal 1.0
```

## Contents

| File | Slides | Run | Expected result |
|------|--------|-----|-----------------|
| `gams/Example01.gms` | 03 | GAMS Studio → F9 | x1 = 2, x2 = 0, Z = 6 |
| `gams/Example01.lst` | 03 | – | real listing file of that run |
| `gamspy/test_gamspy.py` | 04 – Step 6 | `python gamspy/test_gamspy.py` | `ModelStatus.OptimalGlobal 1.0` |
| `gamspy/example01_gams_style.py` | 06 | `python …` | summary table, x1 = 2, x2 = 0, Z = 6 |
| `gamspy/example01.py` | 06 – shorter | `python …` | Z = 6, marginals eq1 = 0, eq2 = 3 |
| `gamspy/exported/example01.gms` | 06 – bonus | output of `model.toGams("exported")` | – |
| `gamspy/latex/example01.tex` | 06 – bonus | output of `model.toLatex("latex")` | – |
| `gamspy/example03_simple.py` | 07 – Step 1 | `python …` | z = 71.667, m1 = 0.583, m2 = 0.417 |
| `gamspy/example03_indexed.py` | 07 – Step 2, what-if | `python …` | 71.667 + what-if table 0.20…0.32 |
| `webapp/mixing_model.py` | 08 – Step 2 | `python mixing_model.py` | optimal + infeasible dict |
| `webapp/plot_mixing.py` | 08 – Step 3 | `python plot_mixing.py` | `mixing_whatif.png` |
| `webapp/app_step4.py` | 08 – Step 4 | `python …` → http://127.0.0.1:5000 | "Hello from Flask!" |
| `webapp/app_step5.py` | 08 – Step 5 | as above | form; 22 % → 76.67 cent/kg |
| `webapp/app_step6.py` | 08 – Step 6 | as above | form + chart, `/plot.png?water=22` |
| `webapp/app.py` + `templates/index.html` | 08 – Step 7 | as above | interactive page, `/api/solve` JSON |
| `figures/make_figures.py` | figures | `python make_figures.py` | the 4 lecture figures (PNG + SVG) |

Run the web app scripts **from inside `webapp/`** (they import each other).
Stop a running Flask server with **Ctrl + C** before starting the next step.
