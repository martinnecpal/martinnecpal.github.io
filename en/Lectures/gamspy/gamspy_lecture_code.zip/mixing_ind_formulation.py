import pandas as pd
import gamspy as gp
import matplotlib.pyplot as plt

# %% model
# data definition
feeds = pd.DataFrame(
    [['feed1', 0.80, 80],
     ['feed2', 0.68, 60]],
    columns=['f', 'MEA', 'cost']
)
wmax_water = 0.25

feeds['water'] = 1 - feeds['MEA']

# split into parameter data
composition = feeds.melt(id_vars='f', value_vars=['MEA', 'water'],
                         var_name='c', value_name='value')
cost_data = feeds[['f', 'cost']].rename(columns={'cost': 'value'})

# gams container definition
m=gp.Container()

# setc definition
f = gp.Set(m, 'f', description='feed steams')
c = gp.Set(m, 'c', description='components')

# parameters definition
W = gp.Parameter(m, 'W', domain=[f,c], records=composition, domain_forwarding=True)
cost = gp.Parameter(m, 'cost', domain=f, records=cost_data)
wmax = gp.Parameter(m, 'wmax', domain=c, records=[['water', wmax_water]])
M = gp.Parameter(m, 'M', records=1)

# variables, equations, model --------------------------------------------------

x = gp.Variable(m, "x", type='positive', domain=f)

spec = gp.Equation(m, 'spec', domain=c)
balance = gp.Equation(m, 'balance')

spec[c].where[wmax[c]] = gp.Sum(f, W[f,c] * x[f]) <= wmax[c] * M
balance[...] = gp.Sum(f,x[f]) == M

# model definition
mixing = gp.Model(m, 'mixing', equations=m.getEquations(),
                  problem='LP',sense="min",
                  objective=gp.Sum(f, cost[f] * x[f]))


# model solve
mixing.solve()
mixing.toLatex('lataxlatex')

# printing values---------------------------------------------------------

print(mixing.objective_value)
print(x.records[['f','level']])


'''
limit_values = [0.20, 0.22, 0.25, 0.28, 0.32]
objectives, x1_values, x2_values = [], [], []
for limits in limit_values:
    wmax.setRecords([['water', limits]])
    mixing.solve()
    x1, x2 = x.records['level']
    print(limits, mixing.objective_value, x1, x2)
    objectives.append(mixing.objective_value)
    x1_values.append(x1)
    x2_values.append(x2)
'''

'''
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(10, 4))
ax1.plot(limit_values, objectives, marker='o')
ax1.set_xlabel('max water fraction')
ax1.set_ylabel('cost')
ax1.set_title('Optimal cost')
ax2.plot(limit_values, x1_values, marker='o', label='feed1')
ax2.plot(limit_values, x2_values, marker='o', label='feed2')
ax2.set_xlabel('max water fraction')
ax2.set_ylabel('feed share')
ax2.set_title('Optimal mix')
ax2.legend()
fig.tight_layout()
fig.savefig('mixing.png', dpi=150)
'''
