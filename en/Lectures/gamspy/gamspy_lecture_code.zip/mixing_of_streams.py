import gamspy as gp

# gams container definition
m = gp.Container()

# variable definition 
m1 = gp.Variable(m, "m1", type="positive", description="mass of feed 1 [kg]")
m2 = gp.Variable(m, "m2", type="positive", description="mass of feed 2 [kg]")

# equations definition
water   = gp.Equation(m, "water")
balance = gp.Equation(m, "balance")
water[...]   = 0.20 * m1 + 0.32 * m2 <= 0.25
balance[...] = m1 + m2 == 1

mixing = gp.Model(m, "mixing", equations=m.getEquations(),
                  problem="LP", sense="min", objective=80 * m1 + 60 * m2)
mixing.solve()

print("Z.l  =", mixing.objective_value)
print("m1=", m1.toValue())
print("m2=", m2.toValue())